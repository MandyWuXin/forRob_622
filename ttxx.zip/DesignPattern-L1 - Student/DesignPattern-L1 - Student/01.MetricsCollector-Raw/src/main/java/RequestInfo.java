public class RequestInfo {
    public RequestInfo(String type, long responseTime, long startTimestamp) {
    }
}
