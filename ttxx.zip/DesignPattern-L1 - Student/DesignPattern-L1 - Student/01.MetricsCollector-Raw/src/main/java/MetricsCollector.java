public class MetricsCollector {
    public void recordRequest(RequestInfo requestInfo) {

    }
}
