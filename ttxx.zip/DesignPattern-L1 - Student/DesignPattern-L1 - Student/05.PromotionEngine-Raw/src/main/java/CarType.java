public enum CarType {
    MPV, SUV, Sedan
}
