#include "stdafx.h"
#include "CppUnitTest.h"
#include "../LoanCalculator_Begin/Date.h"
#include "../LoanCalculator_Begin/Loan.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace LoanCalculator_Begin_Test
{		
	TEST_CLASS(UnitTestLoanCalculator_Begin)
	{
	public:
		
		TEST_METHOD(LoanCalculator_Begin_TestTermLoanCapital)
		{
			Date* pStartDate = new Date(2003, 11, 20);
			Date* pMaturityDate = new Date(2006, 11, 20);
			Loan* pTermLoan = Loan::newTermLoan(3000, pStartDate, pMaturityDate, 1);
			pTermLoan->addPayment(1000.00, new Date(2004, 11, 20));
			pTermLoan->addPayment(1000.00, new Date(2005, 11, 20));
			pTermLoan->addPayment(1000.00, new Date(2006, 11, 20));

			Assert::AreEqual(2.0, pTermLoan->duration(), 0.001);
			Assert::AreEqual(210.00, pTermLoan->capital(), 0.001);

			delete pTermLoan;
			delete pMaturityDate;
			delete pStartDate;
		}

		TEST_METHOD(LoanCalculator_Begin_TestAdvisedLineLoanCapital)
		{
			Date* pStartDate = new Date(2003, 11, 20);
			Date* pExpiryDate = new Date(2006, 11, 20);

			Loan * pAdvisedLineLoan = Loan::newAdvisedLine(3000, pStartDate, pExpiryDate, 2);
			
			Assert::AreEqual(pAdvisedLineLoan->capital(), 31.5, 0.001);
		}

		TEST_METHOD(LoanCalculator_Begin_TestRevolverLoanCapital)
		{
			Date* pStartDate = new Date(2003, 11, 20);
			Date* pExpiryDate = new Date(2006, 11, 20);

			Loan * pRevolverLoan = Loan::newRevolver(3000, pStartDate, pExpiryDate, 2);
			Assert::AreEqual(pRevolverLoan->capital(), 315.0, 0.001);
		}
	};
}