#pragma once

class SystemProfile
{
public:
	SystemProfile();
	~SystemProfile();

	bool isUnixPermissionRequired();
	void setUnixPermissionRequired(bool unixPermissionRequired);

private:
	bool _unixPermissionRequired;
};

