#pragma once

class SystemAdmin
{
public:
	SystemAdmin();
	~SystemAdmin();

	bool operator==(const SystemAdmin& rhs);
};

