#pragma once
class SystemUser
{
public:
	SystemUser();
	~SystemUser();
};

