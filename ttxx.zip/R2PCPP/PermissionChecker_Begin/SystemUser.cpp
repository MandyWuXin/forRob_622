#include "stdafx.h"
#include "SystemUser.h"


SystemUser::SystemUser()
{
}


SystemUser::~SystemUser()
{
}
