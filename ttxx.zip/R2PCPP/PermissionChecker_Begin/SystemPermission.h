#pragma once
#include <string>
#include "SystemAdmin.h"
#include "SystemProfile.h"
#include "SystemUser.h"

using namespace std;

class SystemPermission
{
public:
	SystemPermission(SystemUser *pRequestor, SystemProfile *pProfile);
	~SystemPermission();

	static string REQUESTED;
	static string CLAIMED;
	static string GRANTED;
	static string DENIED;
	static string UNIX_REQUESTED;
	static string UNIX_CLAIMED;

	void claimedBy(SystemAdmin *pAdmin);
	void deniedBy(SystemAdmin *pAdmin);
	void grantedBy(SystemAdmin *pAdmin);

	string getState();
	bool isGranted();

private:
	SystemProfile *_pProfile;
	SystemUser *_pRequestor;
	SystemAdmin *_pAdmin;
	bool _bGranted;
	string _strState;

	bool _bUnixPermissionGranted;

	void notifyAdminOfPermissionRequest();
	void willBeHandledBy(SystemAdmin *pSystemAdmin);

	void notifyUserOfPermissionRequestResult();
	bool isUnixPermissionGranted();

	void notifyUnixAdminsOfPermissionRequest();
};
