#include "stdafx.h"
#include "SystemAdmin.h"


SystemAdmin::SystemAdmin()
{
}


SystemAdmin::~SystemAdmin()
{
}

bool SystemAdmin::operator==(const SystemAdmin & rhs)
{
	return true;
}
