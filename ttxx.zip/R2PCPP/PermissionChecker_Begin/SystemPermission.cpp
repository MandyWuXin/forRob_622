#include "stdafx.h"
#include "SystemPermission.h"


string SystemPermission::GRANTED = "GRANTED";
string SystemPermission::REQUESTED = "REQUESTED";
string SystemPermission::CLAIMED = "CLAIMED";
string SystemPermission::DENIED = "DENIED";
string SystemPermission::UNIX_REQUESTED = "UNIX_REQUESTED ";
string SystemPermission::UNIX_CLAIMED = "UNIX_CLAIMED ";

SystemPermission::SystemPermission(SystemUser *pRequestor, SystemProfile *pProfile)
{
	this->_pAdmin = new SystemAdmin();
	this->_pRequestor = pRequestor;
	this->_pProfile = pProfile;
	this->_strState = REQUESTED;
	this->_bGranted = false;
	this->_bUnixPermissionGranted = false;
	notifyAdminOfPermissionRequest();
}


SystemPermission::~SystemPermission()
{
}

void SystemPermission::notifyAdminOfPermissionRequest()
{
	// notify code goes here.
}

void SystemPermission::claimedBy(SystemAdmin *pAdmin)
{
	if ((_strState != REQUESTED) && (_strState != UNIX_REQUESTED))
		return;

	willBeHandledBy(pAdmin);

	if (_strState == REQUESTED)
		_strState = CLAIMED;
	else if (_strState == UNIX_REQUESTED)
		_strState = UNIX_CLAIMED;
}

void SystemPermission::willBeHandledBy(SystemAdmin *pSystemAdmin)
{
	// handle code goes here.
}

void SystemPermission::deniedBy(SystemAdmin *pAdmin)
{
	if ((_strState != CLAIMED) && (_strState != UNIX_CLAIMED))
		return;

	if (!(*_pAdmin == *pAdmin))
		return;

	_bGranted = false;
	_bUnixPermissionGranted = false;
	_strState = DENIED;
	notifyUserOfPermissionRequestResult();
}

void SystemPermission::notifyUserOfPermissionRequestResult()
{
	// notify code goes here.
}

void SystemPermission::grantedBy(SystemAdmin *pAdmin)
{
	if ((_strState != CLAIMED) && (_strState != UNIX_CLAIMED))
		return;

	if (!(*_pAdmin == *pAdmin))
		return;

	if (_pProfile->isUnixPermissionRequired() && (_strState == UNIX_CLAIMED))
		_bUnixPermissionGranted = true;
	else if (_pProfile->isUnixPermissionRequired() && !isUnixPermissionGranted())
	{
		_strState = UNIX_REQUESTED;
		notifyUnixAdminsOfPermissionRequest();
		return;
	}
	_strState = GRANTED;
	_bGranted = true;
	notifyUserOfPermissionRequestResult();
}

bool SystemPermission::isUnixPermissionGranted()
{
	return _bUnixPermissionGranted;
}

void SystemPermission::notifyUnixAdminsOfPermissionRequest()
{
	// notify code goes here.
}

string SystemPermission::getState()
{
	return _strState;
}

bool SystemPermission::isGranted()
{
	return _bGranted;
}
