#include "stdafx.h"
#include "SystemProfile.h"


SystemProfile::SystemProfile()
{
	this->_unixPermissionRequired = false;
}


SystemProfile::~SystemProfile()
{
}

bool SystemProfile::isUnixPermissionRequired()
{
	return this->_unixPermissionRequired;
}

void SystemProfile::setUnixPermissionRequired(bool unixPermissionRequired)
{
	this->_unixPermissionRequired = unixPermissionRequired;
}
