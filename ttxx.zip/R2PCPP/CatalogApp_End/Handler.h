#pragma once
#include "CatalogApp.h"

class Handler
{
public:
	Handler(CatalogApp *pCatalogApp);
	~Handler();

	virtual HandlerResponse * execute(Map *parameters) = 0;

private:
	CatalogApp *_pCatalogApp;
};

