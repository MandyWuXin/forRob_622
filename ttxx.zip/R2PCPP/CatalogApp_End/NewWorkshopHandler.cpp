#include "stdafx.h"
#include "NewWorkshopHandler.h"
#include "WorkshopManager.h"


NewWorkshopHandler::NewWorkshopHandler(CatalogApp *pCatalogApp): Handler(pCatalogApp)
{
	this->_pCatalogApp = pCatalogApp;
}


NewWorkshopHandler::~NewWorkshopHandler()
{
}

HandlerResponse* NewWorkshopHandler::execute(Map *parameters)
{
	return getNewWorkshopResponse(parameters);
}

HandlerResponse* NewWorkshopHandler::getNewWorkshopResponse(Map* pParameters)
{
	string nextWorkshopID = WorkshopManager::getNextWorkshopID();
	string newWorkshopContents =
		WorkshopManager::createNewFileFromTemplate(
			nextWorkshopID,
			WorkshopManager::getWorkshopDir(),
			WorkshopManager::getWorkshopTemplate()
		);
	WorkshopManager::addWorkshop(newWorkshopContents);
	pParameters->put("id", nextWorkshopID);
	return _pCatalogApp->executeActionAndGetResponse(CatalogApp::ALL_WORKSHOPS, pParameters);
}
