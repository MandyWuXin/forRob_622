#pragma once
#include "HandlerResponse.h"
#include "Map.h"
#include <map>

class Handler;

class CatalogApp
{
public:
	CatalogApp();
	~CatalogApp();	

	HandlerResponse * executeActionAndGetResponse(string strActionName, Map * pParameters);
	
	string getFormattedData(string strAllWorkshops);

public:
	static const string NEW_WORKSHOP;
	static const string ALL_WORKSHOPS;
	static const string ALL_WORKSHOPS_STYLESHEET;

private:
	map<string, Handler*> *_pHandlers;
	void createHandlers();

	Handler * lookupHandlerBy(string actionName);

	HandlerResponse* getNewWorkshopResponse(Map* pParameters);
	HandlerResponse* getAllWorkshopsResponse();
};

