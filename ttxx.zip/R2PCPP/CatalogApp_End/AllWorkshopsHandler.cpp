#include "stdafx.h"
#include "AllWorkshopsHandler.h"
#include "XMLBuilder.h"
#include "WorkshopRepository.h"
#include "WorkshopManager.h"


AllWorkshopsHandler::AllWorkshopsHandler(CatalogApp *pCatalogApp): Handler(pCatalogApp)
{
	this->_pCatalogApp = pCatalogApp;
}


AllWorkshopsHandler::~AllWorkshopsHandler()
{
}

HandlerResponse* AllWorkshopsHandler::execute(Map* parameters)
{
	return getAllWorkshopsResponse();
}

HandlerResponse* AllWorkshopsHandler::getAllWorkshopsResponse()
{
	XMLBuilder *pAllWorkshopsXml = new XMLBuilder("workshops");
	WorkshopRepository *pRepository =
		WorkshopManager::getWorkshopRepository();
	Iterator *pIds = pRepository->keyIterator();
	while (pIds->hasNext())
	{
		string id = (string)pIds->next();
		Workshop *pWorkshop = pRepository->getWorkshop(id);
		pAllWorkshopsXml->addBelowParent("workshop");
		pAllWorkshopsXml->addAttribute("id", pWorkshop->getID());
		pAllWorkshopsXml->addAttribute("name", pWorkshop->getName());
		pAllWorkshopsXml->addAttribute("status", pWorkshop->getStatus());
		pAllWorkshopsXml->addAttribute("duration",
			pWorkshop->getDurationAsString());
	}
	string formattedXml = _pCatalogApp->getFormattedData(pAllWorkshopsXml->toString());
	return new HandlerResponse(formattedXml, CatalogApp::ALL_WORKSHOPS_STYLESHEET);
}
