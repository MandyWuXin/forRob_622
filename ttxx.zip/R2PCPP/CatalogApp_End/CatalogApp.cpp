#include "stdafx.h"
#include "CatalogApp.h"
#include "WorkshopManager.h"
#include "XMLBuilder.h"
#include "NewWorkshopHandler.h"
#include "AllWorkshopsHandler.h"

const string CatalogApp::NEW_WORKSHOP = "NEW_WORKSHOP";
const string CatalogApp::ALL_WORKSHOPS = "ALL_WORKSHOPS";
const string CatalogApp::ALL_WORKSHOPS_STYLESHEET = "ALL_WORKSHOPS_STYLESHEET";

CatalogApp::CatalogApp()
{
}


CatalogApp::~CatalogApp()
{
}

HandlerResponse* CatalogApp::executeActionAndGetResponse(string strActionName, Map* pParameters)
{
	//if (strActionName == NEW_WORKSHOP)    // ������һ���µ����ְ�ʱ
	//{
	//	/*return getNewWorkshopResponse(pParameters);*/
	//	return (new NewWorkshopHandler(this))->execute(pParameters);
	//}
	//else if (strActionName == ALL_WORKSHOPS)  // �������������ְ�ʱ
	//{
	//	/*return getAllWorkshopsResponse();*/
	//	return (new AllWorkshopsHandler(this))->execute(pParameters);
	//}
	//// ... ���кܶ�� else if

	//return NULL;

	Handler *pHandler = lookupHandlerBy(strActionName);
	return pHandler->execute(pParameters);
}

string CatalogApp::getFormattedData(string strAllWorkshops)
{
	// ... 
	return strAllWorkshops;
}

void CatalogApp::createHandlers()
{
	_pHandlers->insert_or_assign(NEW_WORKSHOP, new NewWorkshopHandler(this));
	_pHandlers->insert_or_assign(ALL_WORKSHOPS, new AllWorkshopsHandler(this));
}

Handler* CatalogApp::lookupHandlerBy(string actionName)
{
	return (*_pHandlers)[actionName];
}

HandlerResponse* CatalogApp::getNewWorkshopResponse(Map* pParameters)
{
	string nextWorkshopID = WorkshopManager::getNextWorkshopID();
	string newWorkshopContents =
		WorkshopManager::createNewFileFromTemplate(
			nextWorkshopID,
			WorkshopManager::getWorkshopDir(),
			WorkshopManager::getWorkshopTemplate()
		);
	WorkshopManager::addWorkshop(newWorkshopContents);
	pParameters->put("id", nextWorkshopID);
	return executeActionAndGetResponse(ALL_WORKSHOPS, pParameters);
}

HandlerResponse* CatalogApp::getAllWorkshopsResponse()
{
	XMLBuilder *pAllWorkshopsXml = new XMLBuilder("workshops");
	WorkshopRepository *pRepository =
		WorkshopManager::getWorkshopRepository();
	Iterator *pIds = pRepository->keyIterator();
	while (pIds->hasNext())
	{
		string id = (string)pIds->next();
		Workshop *pWorkshop = pRepository->getWorkshop(id);
		pAllWorkshopsXml->addBelowParent("workshop");
		pAllWorkshopsXml->addAttribute("id", pWorkshop->getID());
		pAllWorkshopsXml->addAttribute("name", pWorkshop->getName());
		pAllWorkshopsXml->addAttribute("status", pWorkshop->getStatus());
		pAllWorkshopsXml->addAttribute("duration",
			pWorkshop->getDurationAsString());
	}
	string formattedXml = getFormattedData(pAllWorkshopsXml->toString());
	return new HandlerResponse(formattedXml, ALL_WORKSHOPS_STYLESHEET);
}
