#pragma once
#include "HandlerResponse.h"
#include "Map.h"
#include "CatalogApp.h"
#include "Handler.h"

class NewWorkshopHandler : public Handler
{
public:
	NewWorkshopHandler(CatalogApp *pCatalogApp);
	~NewWorkshopHandler();

	HandlerResponse * execute(Map *parameters) override;

private:
	CatalogApp *_pCatalogApp;

	HandlerResponse* getNewWorkshopResponse(Map* pParameters);
};

