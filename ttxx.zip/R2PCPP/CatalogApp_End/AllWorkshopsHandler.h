#pragma once
#include "CatalogApp.h"
#include "Handler.h"

class AllWorkshopsHandler : public Handler
{
public:
	AllWorkshopsHandler(CatalogApp *pCatalogApp);
	~AllWorkshopsHandler();

	HandlerResponse * execute(Map *parameters) override;

private:
	CatalogApp *_pCatalogApp;

	HandlerResponse* getAllWorkshopsResponse();
};

