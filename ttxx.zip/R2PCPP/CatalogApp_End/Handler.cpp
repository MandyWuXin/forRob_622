#include "stdafx.h"
#include "Handler.h"

Handler::Handler(CatalogApp* pCatalogApp)
{
	this->_pCatalogApp = pCatalogApp;
}

Handler::~Handler()
{
}
