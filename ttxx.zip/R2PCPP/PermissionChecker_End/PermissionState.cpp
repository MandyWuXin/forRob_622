#include "stdafx.h"
#include "PermissionState.h"
#include "PermissionRequested.h"
#include "PermissionClaimed.h"
#include "PermissionGranted.h"
#include "PermissionDenied.h"
#include "UnixPermissionRequested.h"
#include "UnixPermissionClaimed.h"
#include "SystemPermission.h"

PermissionState * PermissionState::REQUESTED = new PermissionRequested();
PermissionState * PermissionState::CLAIMED = new PermissionClaimed();
PermissionState * PermissionState::GRANTED = new PermissionGranted();
PermissionState * PermissionState::DENIED = new PermissionDenied();
PermissionState * PermissionState::UNIX_REQUESTED = new UnixPermissionRequested();
PermissionState * PermissionState::UNIX_CLAIMED = new UnixPermissionClaimed();


PermissionState::PermissionState(string strState)
{
	this->_strState = strState;
}


PermissionState::~PermissionState()
{
}

string PermissionState::toString()
{
	return this->_strState;
}

void PermissionState::claimedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission)
{
	/*if ((pSystemPermission->getState() != PermissionState::REQUESTED) && (pSystemPermission->getState() != PermissionState::UNIX_REQUESTED))
		return;

	pSystemPermission->willBeHandledBy(pAdmin);

	if (pSystemPermission->getState() == PermissionState::REQUESTED)
		pSystemPermission->setState(PermissionState::CLAIMED);
	else if (pSystemPermission->getState() == PermissionState::UNIX_REQUESTED)
		pSystemPermission->setState(PermissionState::UNIX_CLAIMED);*/
}

void PermissionState::deniedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission)
{
	/*if ((pSystemPermission->getState() != PermissionState::CLAIMED) && (pSystemPermission->getState() != PermissionState::UNIX_CLAIMED))
		return;

	if (!(*pSystemPermission->getSystemAdmin() == *pAdmin))
		return;

	pSystemPermission->setGranted(false);
	pSystemPermission->setUnixPermissionGranted(false);
	pSystemPermission->setState(PermissionState::DENIED);
	pSystemPermission->notifyUserOfPermissionRequestResult();*/
}

void PermissionState::grantedBy(SystemAdmin* pAdmin, SystemPermission* pSystemPermission)
{
	/*if ((pSystemPermission->getState() != PermissionState::CLAIMED) && (pSystemPermission->getState() != PermissionState::UNIX_CLAIMED))
		return;

	if (!(*pSystemPermission->getSystemAdmin() == *pAdmin))
		return;

	if (pSystemPermission->getProfile()->isUnixPermissionRequired() && (pSystemPermission->getState() == PermissionState::UNIX_CLAIMED))
		pSystemPermission->setUnixPermissionGranted(true);
	else if (pSystemPermission->getProfile()->isUnixPermissionRequired() && !pSystemPermission->getUnixPermissionGranted())
	{
		pSystemPermission->setState(PermissionState::UNIX_REQUESTED);
		pSystemPermission->notifyUnixAdminsOfPermissionRequest();
		return;
	}
	pSystemPermission->setState(PermissionState::GRANTED);
	pSystemPermission->setGranted(true);
	pSystemPermission->notifyUserOfPermissionRequestResult();*/
}
