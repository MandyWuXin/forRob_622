#pragma once
#include "PermissionState.h"

class PermissionClaimed : public PermissionState
{
public:
	PermissionClaimed();
	~PermissionClaimed();

	void deniedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission) override;
	void grantedBy(SystemAdmin* pAdmin, SystemPermission* pSystemPermission) override;
};

