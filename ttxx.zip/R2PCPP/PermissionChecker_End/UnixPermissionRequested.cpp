#include "stdafx.h"
#include "UnixPermissionRequested.h"
#include "SystemPermission.h"


UnixPermissionRequested::UnixPermissionRequested() : PermissionState("UNIX_REQUESTED")
{
}


UnixPermissionRequested::~UnixPermissionRequested()
{
}

void UnixPermissionRequested::claimedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission)
{
	pSystemPermission->willBeHandledBy(pAdmin);
	pSystemPermission->setState(PermissionState::UNIX_CLAIMED);
}