#pragma once
#include <string>
#include "SystemAdmin.h"
#include "SystemProfile.h"
#include "SystemUser.h"
#include "PermissionState.h"

using namespace std;

class SystemPermission
{
public:
	SystemPermission(SystemUser *pRequestor, SystemProfile *pProfile);
	~SystemPermission();

	/*static string REQUESTED;
	static string CLAIMED;
	static string GRANTED;
	static string DENIED;
	static string UNIX_REQUESTED;
	static string UNIX_CLAIMED;*/

	void claimedBy(SystemAdmin *pAdmin);
	void deniedBy(SystemAdmin *pAdmin);
	void grantedBy(SystemAdmin *pAdmin);

	//string getState();
	bool isGranted();	

	void willBeHandledBy(SystemAdmin *pSystemAdmin);

	void notifyUserOfPermissionRequestResult();
	void notifyUnixAdminsOfPermissionRequest();

	PermissionState * getState();
	void setState(PermissionState *pState);

	SystemAdmin * getSystemAdmin();
	void setSystemAdmin(SystemAdmin *pSystemAdmin);

	bool getGranted();
	void setGranted(bool isGranted);

	bool getUnixPermissionGranted();
	void setUnixPermissionGranted(bool isUnixPermissionGranted);

	SystemProfile * getProfile();
	void setProfile(SystemProfile *pSystemProfile);	

private:
	SystemProfile *_pProfile;
	SystemUser *_pRequestor;
	SystemAdmin *_pAdmin;
	bool _bGranted;
	PermissionState *_pState;

	bool _bUnixPermissionGranted;

	void notifyAdminOfPermissionRequest();	

	bool isUnixPermissionGranted();	
};
