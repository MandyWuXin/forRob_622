#pragma once
#include "PermissionState.h"

class PermissionDenied : public PermissionState
{
public:
	PermissionDenied();
	~PermissionDenied();
};

