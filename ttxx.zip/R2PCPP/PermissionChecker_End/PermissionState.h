#pragma once
#include <string>
#include "SystemAdmin.h"

class SystemPermission;
using namespace std;

class PermissionState
{
public:
	PermissionState(string strState);
	~PermissionState();

	virtual void claimedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission);
	virtual void deniedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission);
	virtual void grantedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission);

	string toString();

public:
	static PermissionState *REQUESTED;
	static PermissionState *CLAIMED;
	static PermissionState *GRANTED;
	static PermissionState *DENIED;
	static PermissionState *UNIX_REQUESTED;
	static PermissionState *UNIX_CLAIMED;

private:
	string _strState;
};

