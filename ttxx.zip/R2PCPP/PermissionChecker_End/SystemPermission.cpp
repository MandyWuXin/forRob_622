#include "stdafx.h"
#include "SystemPermission.h"

//string SystemPermission::GRANTED = "GRANTED";
//string SystemPermission::REQUESTED = "REQUESTED";
//string SystemPermission::CLAIMED = "CLAIMED";
//string SystemPermission::DENIED = "DENIED";
//string SystemPermission::UNIX_REQUESTED = "UNIX_REQUESTED ";
//string SystemPermission::UNIX_CLAIMED = "UNIX_CLAIMED ";

SystemPermission::SystemPermission(SystemUser *pRequestor, SystemProfile *pProfile)
{
	this->_pAdmin = new SystemAdmin();
	this->_pRequestor = pRequestor;
	this->_pProfile = pProfile;
	this->_pState = PermissionState::REQUESTED;
	this->_bGranted = false;
	this->_bUnixPermissionGranted = false;
	notifyAdminOfPermissionRequest();
}


SystemPermission::~SystemPermission()
{
}

void SystemPermission::notifyAdminOfPermissionRequest()
{
	// notify code goes here.
}

void SystemPermission::claimedBy(SystemAdmin *pAdmin)
{
	/*if ((_pState != PermissionState::REQUESTED) && (_pState != PermissionState::UNIX_REQUESTED))
		return;

	willBeHandledBy(pAdmin);

	if (_pState == PermissionState::REQUESTED)
		_pState = PermissionState::CLAIMED;
	else if (_pState == PermissionState::UNIX_REQUESTED)
		_pState = PermissionState::UNIX_CLAIMED;*/
	
	_pState->claimedBy(pAdmin, this);
}

void SystemPermission::willBeHandledBy(SystemAdmin *pSystemAdmin)
{
	// handle code goes here.
}

void SystemPermission::deniedBy(SystemAdmin *pAdmin)
{
	/*if ((_pState != PermissionState::CLAIMED) && (_pState != PermissionState::UNIX_CLAIMED))
		return;

	if (!(*_pAdmin == *pAdmin))
		return;

	_bGranted = false;
	_bUnixPermissionGranted = false;
	_pState = PermissionState::DENIED;
	notifyUserOfPermissionRequestResult();*/

	_pState->deniedBy(pAdmin, this);
}

void SystemPermission::notifyUserOfPermissionRequestResult()
{
	// notify code goes here.
}

void SystemPermission::grantedBy(SystemAdmin *pAdmin)
{
	/*if ((_pState != PermissionState::CLAIMED) && (_pState != PermissionState::UNIX_CLAIMED))
		return;

	if (!(*_pAdmin == *pAdmin))
		return;

	if (_pProfile->isUnixPermissionRequired() && (_pState == PermissionState::UNIX_CLAIMED))
		_bUnixPermissionGranted = true;
	else if (_pProfile->isUnixPermissionRequired() && !isUnixPermissionGranted())
	{
		_pState = PermissionState::UNIX_REQUESTED;
		notifyUnixAdminsOfPermissionRequest();
		return;
	}
	_pState = PermissionState::GRANTED;
	_bGranted = true;
	notifyUserOfPermissionRequestResult();*/

	_pState->grantedBy(pAdmin, this);
}

bool SystemPermission::isUnixPermissionGranted()
{
	return _bUnixPermissionGranted;
}

void SystemPermission::notifyUnixAdminsOfPermissionRequest()
{
	// notify code goes here.
}

//string SystemPermission::getState()
//{
//	return _pState;
//}

bool SystemPermission::isGranted()
{
	return _bGranted;
}

PermissionState* SystemPermission::getState()
{
	return _pState;
}

void SystemPermission::setState(PermissionState* pState)
{
	this->_pState = pState;
}

SystemAdmin* SystemPermission::getSystemAdmin()
{
	return _pAdmin;
}

void SystemPermission::setSystemAdmin(SystemAdmin* pSystemAdmin)
{
	this->_pAdmin = pSystemAdmin;
}

bool SystemPermission::getGranted()
{
	return _bGranted;
}

void SystemPermission::setGranted(bool isGranted)
{
	_bGranted = isGranted;
}

bool SystemPermission::getUnixPermissionGranted()
{
	return _bUnixPermissionGranted;
}

void SystemPermission::setUnixPermissionGranted(bool isUnixPermissionGranted)
{
	_bUnixPermissionGranted = isUnixPermissionGranted;
}

SystemProfile* SystemPermission::getProfile()
{
	return _pProfile;
}

void SystemPermission::setProfile(SystemProfile* pSystemProfile)
{
	_pProfile = pSystemProfile;
}

