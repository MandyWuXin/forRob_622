#pragma once
#include "PermissionState.h"

class UnixPermissionRequested : public PermissionState
{
public:
	UnixPermissionRequested();
	~UnixPermissionRequested();

	void claimedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission) override;
};

