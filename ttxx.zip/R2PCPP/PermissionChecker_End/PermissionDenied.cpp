#include "stdafx.h"
#include "PermissionDenied.h"


PermissionDenied::PermissionDenied(): PermissionState("DENIED")
{
}


PermissionDenied::~PermissionDenied()
{
}
