#pragma once
#include "PermissionState.h"

class PermissionRequested : public PermissionState
{
public:
	PermissionRequested();
	~PermissionRequested();

	void claimedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission) override;
};

