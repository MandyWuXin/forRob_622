#pragma once
#include "PermissionState.h"

class PermissionGranted : public PermissionState
{
public:
	PermissionGranted();
	~PermissionGranted();
};

