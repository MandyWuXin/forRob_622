#include "stdafx.h"
#include "PermissionGranted.h"


PermissionGranted::PermissionGranted() : PermissionState("GRANTED")
{
}


PermissionGranted::~PermissionGranted()
{
}
