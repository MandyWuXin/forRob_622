#include "stdafx.h"
#include "PermissionClaimed.h"
#include "SystemPermission.h"


PermissionClaimed::PermissionClaimed() : PermissionState("CLAIMED")
{
}


PermissionClaimed::~PermissionClaimed()
{
}

void PermissionClaimed::deniedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission)
{
	if (!(*pSystemPermission->getSystemAdmin() == *pAdmin))
		return;

	pSystemPermission->setGranted(false);
	pSystemPermission->setUnixPermissionGranted(false);
	pSystemPermission->setState(PermissionState::DENIED);
	pSystemPermission->notifyUserOfPermissionRequestResult();
}

void PermissionClaimed::grantedBy(SystemAdmin* pAdmin, SystemPermission* pSystemPermission)
{
	if (!(*pSystemPermission->getSystemAdmin() == *pAdmin))
		return;

	if (pSystemPermission->getProfile()->isUnixPermissionRequired() && !pSystemPermission->getUnixPermissionGranted())
	{
		pSystemPermission->setState(PermissionState::UNIX_REQUESTED);
		pSystemPermission->notifyUnixAdminsOfPermissionRequest();
		return;
	}
	pSystemPermission->setState(PermissionState::GRANTED);
	pSystemPermission->setGranted(true);
	pSystemPermission->notifyUserOfPermissionRequestResult();
}