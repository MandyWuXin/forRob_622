#include "stdafx.h"
#include "PermissionRequested.h"
#include "SystemPermission.h"


PermissionRequested::PermissionRequested() : PermissionState("REQUESTED")
{
}


PermissionRequested::~PermissionRequested()
{
}

void PermissionRequested::claimedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission)
{
	pSystemPermission->willBeHandledBy(pAdmin);
	pSystemPermission->setState(PermissionState::CLAIMED);
}
