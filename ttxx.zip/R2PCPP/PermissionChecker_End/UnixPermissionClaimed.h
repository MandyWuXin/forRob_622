#pragma once
#include "PermissionState.h"

class UnixPermissionClaimed : public PermissionState
{
public:
	UnixPermissionClaimed();
	~UnixPermissionClaimed();

	void deniedBy(SystemAdmin *pAdmin, SystemPermission *pSystemPermission) override;
	void grantedBy(SystemAdmin* pAdmin, SystemPermission* pSystemPermission) override;
};

