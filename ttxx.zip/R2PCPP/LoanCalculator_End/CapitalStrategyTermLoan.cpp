#include "stdafx.h"
#include "CapitalStrategyTermLoan.h"


CapitalStrategyTermLoan::CapitalStrategyTermLoan()
{
}


CapitalStrategyTermLoan::~CapitalStrategyTermLoan()
{
}

double CapitalStrategyTermLoan::capital(Loan *pLoan)
{
	return pLoan->get_commitment() * pLoan->duration() * riskFactor(pLoan);
}

double CapitalStrategyTermLoan::duration(Loan *pLoan)
{
	return weightedAverageDuration(pLoan);
}