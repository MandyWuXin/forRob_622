#include "stdafx.h"
#include "CapitalStrategyRevolver.h"


CapitalStrategyRevolver::CapitalStrategyRevolver()
{
}


CapitalStrategyRevolver::~CapitalStrategyRevolver()
{
}

double CapitalStrategyRevolver::capital(Loan *pLoan)
{
	return (pLoan->outstandingRiskAmount() * pLoan->duration() * riskFactor(pLoan))
		+ (pLoan->unusedRiskAmount() * pLoan->duration() * unusedRiskFactor(pLoan));
}

double CapitalStrategyRevolver::duration(Loan *pLoan)
{
	return yearsTo(pLoan->get_expiry(), pLoan);
}
