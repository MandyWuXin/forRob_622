#pragma once
#include "CapitalStrategy.h"

class CapitalStrategyAdvisedLine : public CapitalStrategy
{
public:
	CapitalStrategyAdvisedLine();
	~CapitalStrategyAdvisedLine();

	double capital(Loan *pLoan) override;
	double duration(Loan *pLoan) override;
};

