#pragma once
#include "CapitalStrategy.h"

class CapitalStrategyRevolver : public CapitalStrategy
{
public:
	CapitalStrategyRevolver();
	~CapitalStrategyRevolver();

	double capital(Loan *pLoan) override;
	double duration(Loan *pLoan) override;
};

