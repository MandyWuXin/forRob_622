#pragma once
#include "Payment.h"
#include <vector>

class CapitalStrategy;

class Loan
{
public:
	static Loan * newTermLoan(double commitment, Date *pStart, Date *pMaturity, int riskRating);
	static Loan * newRevolver(double commitment, Date *pStart, Date *pExpiry, int riskRating);
	static Loan * newAdvisedLine(double commitment, Date *pStart, Date *pExpiry, int riskRating);

	double capital();
	double duration();

	void addPayment(double amount, Date *pDate);

	Date* get_expiry()
	{
		return _pExpiry;
	}

	Date* get_maturity()
	{
		return _pMaturity;
	}

	Date* get_today()
	{
		return _pToday;
	}

	Date* get_start()
	{
		return _pStart;
	}

	double get_commitment()
	{
		return _commitment;
	}

	int get_riskRating()
	{
		return _riskRating;
	}

	std::vector<Payment> get_payments()
	{
		return _payments;
	}	

	double getUnusedPercentage();
	double outstandingRiskAmount();
	double unusedRiskAmount();	

	~Loan();

private:
	Loan(double commitment, double outstanding, Date *pStart, Date *pExpiry, Date *pMaturity, int riskRating, CapitalStrategy *pCapitalStrategy);

	void setUnusedPercentage(double unusedPercentage);
	
	//double riskFactor();
	//double unusedRiskFactor();

	//double weightedAverageDuration();
	//double yearsTo(Date *pEndDate);

	//const int MILLIS_PER_DAY = 86400000;
	//const int DAYS_PER_YEAR = 365;

	Date *_pExpiry; 				// ��Ч��
	Date *_pMaturity; 				// ������
	Date *_pToday; 					// ����
	Date *_pStart; 					// ��ʼ��

	double _commitment; 			// ��ŵ���
	double _outstanding; 			// δ����
	double _unusedPercentage; 		// δ�÷ݶ�
	int _riskRating; 				// ��������

	std::vector<Payment> _payments; 	// ֧����¼
	CapitalStrategy *_capitalStrategy;
};

