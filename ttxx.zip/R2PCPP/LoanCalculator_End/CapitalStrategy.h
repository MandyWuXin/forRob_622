#pragma once
#include "Loan.h"

class CapitalStrategy
{
public:
	CapitalStrategy();
	~CapitalStrategy();

	virtual  double capital(Loan *pLoan) = 0;
	virtual double duration(Loan *pLoan) = 0;

protected:
	double riskFactor(Loan *pLoan);
	double weightedAverageDuration(Loan *pLoan);
	double yearsTo(Date *pEndDate, Loan *pLoan);
	double unusedRiskFactor(Loan *pLoan);
};

