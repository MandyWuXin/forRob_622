#include "stdafx.h"
#include "CapitalStrategy.h"
#include "RiskFactor.h"
#include "UnusedRiskFactors.h"

const int MILLIS_PER_DAY = 86400000;
const int DAYS_PER_YEAR = 365;

CapitalStrategy::CapitalStrategy()
{
}


CapitalStrategy::~CapitalStrategy()
{
}

//double CapitalStrategy::capital(Loan *pLoan)
//{
//	// ��Ч��Ϊ�գ������ղ�Ϊ�գ���Ϊ���ڴ���
//	if (pLoan->get_expiry() == NULL && pLoan->get_maturity() != NULL)
//		return pLoan->get_commitment() * pLoan->duration() * riskFactor(pLoan);
//
//	// ��Ч�ڲ�Ϊ�գ�������Ϊ�գ���Ϊѭ������������ö�ȴ���
//	if (pLoan->get_expiry() != NULL && pLoan->get_maturity() == NULL)
//	{
//		if (pLoan->getUnusedPercentage() != 1.0)  // ���ö�ȴ���
//			return pLoan->get_commitment() * pLoan->getUnusedPercentage() * pLoan->duration() * riskFactor(pLoan);
//		else                               // ѭ������
//			return (pLoan->outstandingRiskAmount() * pLoan->duration() * riskFactor(pLoan))
//			+ (pLoan->unusedRiskAmount() * pLoan->duration() * unusedRiskFactor(pLoan));
//	}
//
//	return 0.0;
//}

double CapitalStrategy::riskFactor(Loan *pLoan)
{
	return RiskFactor::getFactors()->forRating(pLoan->get_riskRating());
}

double CapitalStrategy::unusedRiskFactor(Loan *pLoan)
{
	return UnusedRiskFactors::getFactors()->forRating(pLoan->get_riskRating());
}

//double CapitalStrategy::duration(Loan *pLoan)
//{
//	// ��Ч��Ϊ�գ������ղ�Ϊ�գ���Ϊ���ڴ���
//	if (pLoan->get_expiry() == NULL && pLoan->get_maturity() != NULL)
//		return weightedAverageDuration(pLoan);
//	// ��Ч�ڲ�Ϊ�գ�������Ϊ�գ���Ϊѭ������������ö�ȴ���
//	else if (pLoan->get_expiry() != NULL && pLoan->get_maturity() == NULL)
//		return yearsTo(pLoan->get_expiry(), pLoan);
//	return 0.0;
//}

double CapitalStrategy::weightedAverageDuration(Loan *pLoan)
{
	double duration = 0.0;
	double weightedAverage = 0.0;
	double sumOfPayments = 0.0;

	for (size_t i = 0; i < pLoan->get_payments().size(); i++)
	{
		sumOfPayments += pLoan->get_payments()[i].getAmount();
		weightedAverage += yearsTo(pLoan->get_payments()[i].getDate(), pLoan) * pLoan->get_payments()[i].getAmount();
	}

	if (pLoan->get_commitment() != 0.0)
		duration = weightedAverage / sumOfPayments;

	return duration;
}

double CapitalStrategy::yearsTo(Date *pEndDate, Loan *pLoan)
{
	Date *pBeginDate = (pLoan->get_today() == NULL ? pLoan->get_start() : pLoan->get_today());
	return (*pEndDate - *pBeginDate) / DAYS_PER_YEAR;
}