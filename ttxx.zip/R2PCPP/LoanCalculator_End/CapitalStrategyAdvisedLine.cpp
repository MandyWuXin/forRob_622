#include "stdafx.h"
#include "CapitalStrategyAdvisedLine.h"


CapitalStrategyAdvisedLine::CapitalStrategyAdvisedLine()
{
}


CapitalStrategyAdvisedLine::~CapitalStrategyAdvisedLine()
{
}

double CapitalStrategyAdvisedLine::capital(Loan *pLoan)
{
	return pLoan->get_commitment() * pLoan->getUnusedPercentage() * pLoan->duration() * riskFactor(pLoan);
}

double CapitalStrategyAdvisedLine::duration(Loan *pLoan)
{
	return yearsTo(pLoan->get_expiry(), pLoan);
}