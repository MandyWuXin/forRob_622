#pragma once
#include "CapitalStrategy.h"

class CapitalStrategyTermLoan : public CapitalStrategy
{
public:
	CapitalStrategyTermLoan();
	~CapitalStrategyTermLoan();

	double capital(Loan *pLoan) override;
	double duration(Loan *pLoan) override;
};

