#include "stdafx.h"
#include "Loan.h"
#include "UnusedRiskFactors.h"
#include "RiskFactor.h"
#include "CapitalStrategy.h"
#include "CapitalStrategyTermLoan.h"
#include "CapitalStrategyAdvisedLine.h"
#include "CapitalStrategyRevolver.h"

using namespace std;

Loan::Loan(double commitment, double outstanding, Date *pStart, Date *pExpiry, Date *pMaturity, int riskRating, CapitalStrategy *pCapitalStrategy)
{
	this->_commitment = commitment;
	this->_outstanding = outstanding;
	this->_pStart = pStart;
	this->_pExpiry = pExpiry;
	this->_pMaturity = pMaturity;
	this->_riskRating = riskRating;
	this->_capitalStrategy = pCapitalStrategy;

	this->_unusedPercentage = 1.0;
}

Loan::~Loan()
{
}

Loan * Loan::newTermLoan(double commitment, Date *pStart, Date *pMaturity, int riskRating)
{
	return new Loan(commitment, commitment, pStart, NULL, pMaturity, riskRating, new CapitalStrategyTermLoan());
}

Loan * Loan::newRevolver(double commitment, Date *pStart, Date *pExpiry, int riskRating)
{
	return new Loan(commitment, 0, pStart, pExpiry, NULL, riskRating, new CapitalStrategyRevolver());
}

Loan * Loan::newAdvisedLine(double commitment, Date *pStart, Date *pExpiry, int riskRating)
{
	if (riskRating > 3)
		return NULL;

	Loan* advisedLine = new Loan(commitment, 0, pStart, pExpiry, NULL, riskRating, new CapitalStrategyAdvisedLine());
	advisedLine->setUnusedPercentage(0.1);
	return advisedLine;
}

void Loan::addPayment(double amount, Date *pDate)
{
	Payment *pPayment = new Payment(amount, pDate);
	this->_payments.push_back(*pPayment);
}

double Loan::capital()
{
	//// ��Ч��Ϊ�գ������ղ�Ϊ�գ���Ϊ���ڴ���
	//if (_pExpiry == NULL && _pMaturity != NULL)
	//	return _commitment * duration() * riskFactor();

	//// ��Ч�ڲ�Ϊ�գ�������Ϊ�գ���Ϊѭ������������ö�ȴ���
	//if (_pExpiry != NULL && _pMaturity == NULL)
	//{
	//	if (getUnusedPercentage() != 1.0)  // ���ö�ȴ���
	//		return _commitment * getUnusedPercentage() * duration() * riskFactor();
	//	else                               // ѭ������
	//		return (outstandingRiskAmount() * duration() * riskFactor())
	//		+ (unusedRiskAmount() * duration() * unusedRiskFactor());
	//}

	//return 0.0;

	return (_capitalStrategy)->capital(this);
}

double Loan::duration()
{
	//// ��Ч��Ϊ�գ������ղ�Ϊ�գ���Ϊ���ڴ���
	//if (_pExpiry == NULL && _pMaturity != NULL)
	//	return weightedAverageDuration();
	//// ��Ч�ڲ�Ϊ�գ�������Ϊ�գ���Ϊѭ������������ö�ȴ���
	//else if (_pExpiry != NULL && _pMaturity == NULL)
	//	return yearsTo(_pExpiry);
	//return 0.0;

	return (_capitalStrategy)->duration(this);
}

//double Loan::weightedAverageDuration()
//{
//	double duration = 0.0;
//	double weightedAverage = 0.0;
//	double sumOfPayments = 0.0;
//
//	for (size_t i = 0; i < this->_payments.size(); i++)
//	{
//		sumOfPayments += this->_payments[i].getAmount();
//		weightedAverage += yearsTo(this->_payments[i].getDate()) * this->_payments[i].getAmount();
//	}
//
//	if (_commitment != 0.0)
//		duration = weightedAverage / sumOfPayments;
//
//	return duration;
//}
//
//double Loan::yearsTo(Date *pEndDate)
//{
//	Date *pBeginDate = (_pToday == NULL ? _pStart : _pToday);
//	return (*pEndDate - *pBeginDate) / DAYS_PER_YEAR;
//}

//double Loan::riskFactor()
//{
//	return RiskFactor::getFactors()->forRating(_riskRating);
//}

double Loan::getUnusedPercentage()
{
	return _unusedPercentage;
}

void Loan::setUnusedPercentage(double unusedPercentage)
{
	this->_unusedPercentage = unusedPercentage;
}

double Loan::unusedRiskAmount()
{
	return (_commitment - _outstanding);
}

double Loan::outstandingRiskAmount()
{
	return _outstanding;
}

//double Loan::unusedRiskFactor()
//{
//	return UnusedRiskFactors::getFactors()->forRating(_riskRating);
//}
