#include "stdafx.h"
#include "CppUnitTest.h"
#include "../PermissionChecker_Begin/SystemPermission.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace PermissionChecker_Begin_Test
{		
	TEST_CLASS(UnitTestPermissionChecker_Begin)
	{
	public:
		// Unix
		TEST_METHOD(PermissionChecker_Begin_Unix_TestClaimedBy)
		{
			SystemUser *pUser = new SystemUser();
			SystemProfile *pProfile = new SystemProfile();
			pProfile->setUnixPermissionRequired(true);
			SystemPermission *pPermission = new SystemPermission(pUser, pProfile);
			SystemAdmin *pAdmin = new SystemAdmin();

			pPermission->claimedBy(pAdmin);
			Assert::IsTrue(SystemPermission::CLAIMED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::UNIX_REQUESTED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->claimedBy(pAdmin);
			Assert::IsTrue(SystemPermission::UNIX_CLAIMED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			delete pAdmin;
			delete pPermission;
			delete pProfile;
			delete pUser;
		}

		TEST_METHOD(PermissionChecker_Begin_Unix_TestGrantedBy)
		{
			SystemUser *pUser = new SystemUser();
			SystemProfile *pProfile = new SystemProfile();
			pProfile->setUnixPermissionRequired(true);
			SystemPermission *pPermission = new SystemPermission(pUser, pProfile);
			SystemAdmin *pAdmin = new SystemAdmin();
			
			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::REQUESTED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->claimedBy(pAdmin);
			pPermission->grantedBy(pAdmin);
			pPermission->claimedBy(pAdmin);
			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::GRANTED == pPermission->getState());
			Assert::AreEqual(true, pPermission->isGranted());

			delete pAdmin;
			delete pPermission;
			delete pProfile;
			delete pUser;
		}

		TEST_METHOD(PermissionChecker_Begin_Unix_TestDeniedBy)
		{
			SystemUser *pUser = new SystemUser();
			SystemProfile *pProfile = new SystemProfile();
			pProfile->setUnixPermissionRequired(true);
			SystemPermission *pPermission = new SystemPermission(pUser, pProfile);
			SystemAdmin *pAdmin = new SystemAdmin();

			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::REQUESTED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->claimedBy(pAdmin);
			pPermission->grantedBy(pAdmin);
			pPermission->claimedBy(pAdmin);
			pPermission->deniedBy(pAdmin);
			Assert::IsTrue(SystemPermission::DENIED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			delete pAdmin;
			delete pPermission;
			delete pProfile;
			delete pUser;
		}

		// Non-Unix
		TEST_METHOD(PermissionChecker_Begin_NonUnix_TestClaimedBy)
		{
			SystemUser *pUser = new SystemUser();
			SystemProfile *pProfile = new SystemProfile();
			SystemPermission *pPermission = new SystemPermission(pUser, pProfile);
			SystemAdmin *pAdmin = new SystemAdmin();

			pPermission->claimedBy(pAdmin);
			Assert::IsTrue(SystemPermission::CLAIMED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::GRANTED == pPermission->getState());
			Assert::AreEqual(true, pPermission->isGranted());

			pPermission->claimedBy(pAdmin);
			Assert::IsTrue(SystemPermission::GRANTED == pPermission->getState());
			Assert::AreEqual(true, pPermission->isGranted());

			delete pAdmin;
			delete pPermission;
			delete pProfile;
			delete pUser;
		}

		TEST_METHOD(PermissionChecker_Begin_NonUnix_TestGrantedBy)
		{
			SystemUser *pUser = new SystemUser();
			SystemProfile *pProfile = new SystemProfile();
			SystemPermission *pPermission = new SystemPermission(pUser, pProfile);
			SystemAdmin *pAdmin = new SystemAdmin();

			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::REQUESTED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->claimedBy(pAdmin);
			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::GRANTED == pPermission->getState());
			Assert::AreEqual(true, pPermission->isGranted());

			delete pAdmin;
			delete pPermission;
			delete pProfile;
			delete pUser;
		}

		TEST_METHOD(PermissionChecker_Begin_NonUnix_TestDeniedBy)
		{
			SystemUser *pUser = new SystemUser();
			SystemProfile *pProfile = new SystemProfile();
			SystemPermission *pPermission = new SystemPermission(pUser, pProfile);
			SystemAdmin *pAdmin = new SystemAdmin();

			pPermission->grantedBy(pAdmin);
			Assert::IsTrue(SystemPermission::REQUESTED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			pPermission->claimedBy(pAdmin);
			pPermission->deniedBy(pAdmin);
			Assert::IsTrue(SystemPermission::DENIED == pPermission->getState());
			Assert::AreEqual(false, pPermission->isGranted());

			delete pAdmin;
			delete pPermission;
			delete pProfile;
			delete pUser;
		}
	};
}