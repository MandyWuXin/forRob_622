#include "stdafx.h"
#include "WorkshopManager.h"


WorkshopManager::WorkshopManager()
{
}


WorkshopManager::~WorkshopManager()
{
}

string WorkshopManager::getNextWorkshopID()
{
	return "0";
}

void WorkshopManager::addWorkshop(string strNewWorkshopContents)
{
}

string WorkshopManager::getWorkshopDir()
{
	return "WorkshopDir";
}

string WorkshopManager::getWorkshopTemplate()
{
	return "WorkshopTemplate";
}

string WorkshopManager::createNewFileFromTemplate(string strNextWorkshopId, string strFilename,  string strGetWorkshopTemplate)
{
	return "NewFile";
}

WorkshopRepository* WorkshopManager::getWorkshopRepository()
{
	return NULL;
}
