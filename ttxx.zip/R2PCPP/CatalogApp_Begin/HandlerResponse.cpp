#include "stdafx.h"
#include "HandlerResponse.h"


HandlerResponse::HandlerResponse(string strBuilder, string strAllWorkshopsStyleSheet)
{
	this->_strBuilder = strBuilder;
	this->_strAllWorkshopsStyleSheet = strAllWorkshopsStyleSheet;
}


HandlerResponse::~HandlerResponse()
{
}
