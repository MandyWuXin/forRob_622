#include "stdafx.h"
#include "Map.h"


Map::Map()
{
}


Map::~Map()
{
}

void Map::put(string strId, string strNextWorkshopId)
{
}
