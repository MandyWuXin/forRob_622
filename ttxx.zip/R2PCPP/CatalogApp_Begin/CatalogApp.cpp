#include "stdafx.h"
#include "CatalogApp.h"
#include "WorkshopManager.h"
#include "XMLBuilder.h"

const string CatalogApp::NEW_WORKSHOP = "NEW_WORKSHOP";
const string CatalogApp::ALL_WORKSHOPS = "ALL_WORKSHOPS";
const string CatalogApp::ALL_WORKSHOPS_STYLESHEET = "ALL_WORKSHOPS_STYLESHEET";

CatalogApp::CatalogApp()
{
}


CatalogApp::~CatalogApp()
{
}

HandlerResponse* CatalogApp::executeActionAndGetResponse(string strActionName, Map* pParameters)
{
	if (strActionName == NEW_WORKSHOP)    // ������һ���µ����ְ�ʱ
	{
		string nextWorkshopID = WorkshopManager::getNextWorkshopID();
		string newWorkshopContents =
			WorkshopManager::createNewFileFromTemplate(
				nextWorkshopID,
				WorkshopManager::getWorkshopDir(),
				WorkshopManager::getWorkshopTemplate()
			);
		WorkshopManager::addWorkshop(newWorkshopContents);
		pParameters->put("id", nextWorkshopID);
		return executeActionAndGetResponse(ALL_WORKSHOPS, pParameters);
	}
	else if (strActionName == ALL_WORKSHOPS)  // �������������ְ�ʱ
	{
		XMLBuilder *pAllWorkshopsXml = new XMLBuilder("workshops");
		WorkshopRepository *pRepository =
			WorkshopManager::getWorkshopRepository();
		Iterator *pIds = pRepository->keyIterator();
		while (pIds->hasNext())
		{
			string id = (string)pIds->next();
			Workshop *pWorkshop = pRepository->getWorkshop(id);
			pAllWorkshopsXml->addBelowParent("workshop");
			pAllWorkshopsXml->addAttribute("id", pWorkshop->getID());
			pAllWorkshopsXml->addAttribute("name", pWorkshop->getName());
			pAllWorkshopsXml->addAttribute("status", pWorkshop->getStatus());
			pAllWorkshopsXml->addAttribute("duration",
				pWorkshop->getDurationAsString());
		}
		string formattedXml = getFormattedData(pAllWorkshopsXml->toString());
		return new HandlerResponse(formattedXml, ALL_WORKSHOPS_STYLESHEET);
	}
	// ... ���кܶ�� else if

	return NULL;
}

string CatalogApp::getFormattedData(string strAllWorkshops)
{
	// ... 
	return strAllWorkshops;
}
