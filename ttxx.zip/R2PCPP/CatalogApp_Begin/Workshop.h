#pragma once
#include <string>

using namespace std;

class Workshop
{
public:
	Workshop();
	~Workshop();

	string getID();
	string getName();
	string getStatus();
	string getDurationAsString();
};

