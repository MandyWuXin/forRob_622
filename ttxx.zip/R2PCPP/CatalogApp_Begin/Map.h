#pragma once
#include <string>

using namespace std;

class Map
{
public:
	Map();
	~Map();

	void put(string strId, string strNextWorkshopId);
};

