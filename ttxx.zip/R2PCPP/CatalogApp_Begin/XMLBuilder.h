#pragma once
#include <string>

using namespace std;

class XMLBuilder
{
public:
	XMLBuilder(string strVersion);
	~XMLBuilder();

	string toString();
	void addBelowParent(string strWorkshop);
	void addAttribute(string strId, string strGetId);

private:
	string _strVersion;
};

