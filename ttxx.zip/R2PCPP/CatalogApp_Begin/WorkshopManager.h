#pragma once
#include <string>
#include "WorkshopRepository.h"

using namespace std;

class WorkshopManager
{
public:
	WorkshopManager();
	~WorkshopManager();

	static string getNextWorkshopID();
	static void addWorkshop(string strNewWorkshopContents);
	static string getWorkshopDir();
	static string getWorkshopTemplate();
	static string createNewFileFromTemplate(string strNextWorkshopId, string strFilename, string strGetWorkshopTemplate);
	static WorkshopRepository *getWorkshopRepository();
};

