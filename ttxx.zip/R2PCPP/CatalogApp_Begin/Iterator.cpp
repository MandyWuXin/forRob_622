#include "stdafx.h"
#include "Iterator.h"


Iterator::Iterator()
{
}


Iterator::~Iterator()
{
}

bool Iterator::hasNext()
{
	return false;
}

string Iterator::next()
{
	return "next";
}
