#pragma once
#include <string>

using namespace std;

class Iterator
{
public:
	Iterator();
	~Iterator();

	bool hasNext();
	string next();
};

