#include "stdafx.h"
#include "XMLBuilder.h"


XMLBuilder::XMLBuilder(string strVersion)
{
	this->_strVersion = strVersion;
}


XMLBuilder::~XMLBuilder()
{
}

string XMLBuilder::toString()
{
	return _strVersion;
}

void XMLBuilder::addBelowParent(string strWorkshop)
{
}

void XMLBuilder::addAttribute(string strId, string strGetId)
{
}
