#pragma once
#include <string>

using namespace std;

class HandlerResponse
{
public:
	HandlerResponse(string strBuilder, string strAllWorkshopsStyleSheet);
	~HandlerResponse();

private:
	string _strAllWorkshopsStyleSheet;
	string _strBuilder;
};

