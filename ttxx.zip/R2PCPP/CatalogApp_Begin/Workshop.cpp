#include "stdafx.h"
#include "Workshop.h"


Workshop::Workshop()
{
}


Workshop::~Workshop()
{
}

string Workshop::getID()
{
	return "1";
}

string Workshop::getName()
{
	return "Test Workshop";
}

string Workshop::getStatus()
{
	return "Unknown";
}

string Workshop::getDurationAsString()
{
	return "Long Term";
}
