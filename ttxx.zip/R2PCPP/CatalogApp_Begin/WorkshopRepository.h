#pragma once
#include <string>
#include "Iterator.h"
#include "Workshop.h"

using namespace std;

class WorkshopRepository
{
public:
	WorkshopRepository();
	~WorkshopRepository();

	Workshop * getWorkshop(string strId);
	Iterator * keyIterator();
};

