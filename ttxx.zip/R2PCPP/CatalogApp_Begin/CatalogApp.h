#pragma once
#include "HandlerResponse.h"
#include "Map.h"

class CatalogApp
{
public:
	CatalogApp();
	~CatalogApp();

	HandlerResponse * executeActionAndGetResponse(string strActionName, Map * pParameters);

private:
	static const string NEW_WORKSHOP;
	static const string ALL_WORKSHOPS;
	static const string ALL_WORKSHOPS_STYLESHEET;

	string getFormattedData(string strAllWorkshops);
};

