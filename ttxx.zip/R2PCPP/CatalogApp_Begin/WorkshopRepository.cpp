#include "stdafx.h"
#include "WorkshopRepository.h"


WorkshopRepository::WorkshopRepository()
{
}


WorkshopRepository::~WorkshopRepository()
{
}

Workshop* WorkshopRepository::getWorkshop(string strId)
{
	return NULL;
}

Iterator* WorkshopRepository::keyIterator()
{
	return NULL;
}
