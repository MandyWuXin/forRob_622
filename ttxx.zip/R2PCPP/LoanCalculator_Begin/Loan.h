#pragma once
#include "Payment.h"
#include <vector>

class Loan
{
public:
	static Loan * newTermLoan(double commitment, Date *pStart, Date *pMaturity, int riskRating);
	static Loan * newRevolver(double commitment, Date *pStart, Date *pExpiry, int riskRating);
	static Loan * newAdvisedLine(double commitment, Date *pStart, Date *pExpiry, int riskRating);

	double capital();
	double duration();

	void addPayment(double amount, Date *pDate);

	~Loan();

private:
	Loan(double commitment, double outstanding, Date *pStart, Date *pExpiry, Date *pMaturity, int riskRating);

	double weightedAverageDuration();
	double yearsTo(Date *pEndDate);
	double riskFactor();
	double getUnusedPercentage();
	void setUnusedPercentage(double unusedPercentage);
	double unusedRiskAmount();
	double outstandingRiskAmount();
	double unusedRiskFactor();

	const int MILLIS_PER_DAY = 86400000;
	const int DAYS_PER_YEAR = 365;

	Date *_pExpiry; 				// ��Ч��
	Date *_pMaturity; 				// ������
	Date *_pToday; 					// ����
	Date *_pStart; 					// ��ʼ��

	double _commitment; 			// ��ŵ���
	double _outstanding; 			// δ����
	double _unusedPercentage; 		// δ�÷ݶ�
	int _riskRating; 				// ��������

	std::vector<Payment> _payments; 	// ֧����¼
};

