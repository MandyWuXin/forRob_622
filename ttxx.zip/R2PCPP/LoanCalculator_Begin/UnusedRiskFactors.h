#pragma once
#include "Factors.h"

class UnusedRiskFactors
{
public:
	UnusedRiskFactors();
	~UnusedRiskFactors();

	static Factors * getFactors();

private:
	static Factors * pFactors;
};

