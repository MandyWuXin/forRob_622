#include "stdafx.h"
#include "UnusedRiskFactors.h"

Factors * UnusedRiskFactors::pFactors = new Factors();

UnusedRiskFactors::UnusedRiskFactors()
{
}


UnusedRiskFactors::~UnusedRiskFactors()
{
}

Factors * UnusedRiskFactors::getFactors()
{
	return pFactors;
}
