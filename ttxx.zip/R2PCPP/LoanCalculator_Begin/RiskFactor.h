#pragma once
#include "Factors.h"

class RiskFactor
{
public:
	RiskFactor();
	~RiskFactor();

	static Factors * getFactors();

private:
	static Factors * pFactors;
};

