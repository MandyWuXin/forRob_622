#include "stdafx.h"
#include "Payment.h"


Payment::Payment(double amount, Date *pGetDate)
{
	this->_amount = amount;
	this->_pDate = pGetDate;
}

Payment::~Payment()
{
}

double Payment::getAmount()
{
	return this->_amount;
}

Date * Payment::getDate()
{
	return this->_pDate;
}
