#include "stdafx.h"
#include "RiskFactor.h"


Factors * RiskFactor::pFactors = new Factors();

RiskFactor::RiskFactor()
{
}

RiskFactor::~RiskFactor()
{
}

Factors * RiskFactor::getFactors()
{
	return pFactors;
}
