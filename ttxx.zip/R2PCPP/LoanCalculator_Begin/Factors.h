#pragma once

class Factors
{
public:
	Factors();
	~Factors();

	double forRating(double riskRating);
};
