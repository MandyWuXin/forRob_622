#include "stdafx.h"
#include "Factors.h"


Factors::Factors()
{
}


Factors::~Factors()
{
}

double Factors::forRating(double riskRating)
{
	return 0.035;
}
