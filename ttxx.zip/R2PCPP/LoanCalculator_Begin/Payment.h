#pragma once
#include "Date.h"

class Payment
{
public:
	Payment(double amount, Date *pDate);
	~Payment();

	double getAmount();
	Date * getDate();

private:
	double _amount;
	Date *_pDate;
};

