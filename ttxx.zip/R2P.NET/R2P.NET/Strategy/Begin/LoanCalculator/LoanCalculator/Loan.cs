﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanCalculator
{
    // 代码为银行贷款的资金计算类，可以处理定期、循环、建议信用额度三种类型的贷款额度计算
    // 代码中包含了数量可观的用来执行资金计算的条件逻辑，我们将通过 Strategy 模式将其重构
    public class Loan
    {
        private readonly int MILLIS_PER_DAY = 86400000;
        private readonly int DAYS_PER_YEAR = 365;

        private Date expiry;
        private Date maturity;
        private Date today;
        private Date start;

        private double commitment;
        private double outstanding;
        private double riskRating;
        private double unusedPercentage;

        private List<Payment> payments = new List<Payment>();

        private Loan(double commitment, double outstanding, Date start, Date expiry, Date maturity, int riskRating)
        {
            this.commitment = commitment;
            this.outstanding = outstanding;
            this.start = start;
            this.expiry = expiry;
            this.maturity = maturity;
            this.riskRating = riskRating;
        }

        public static Loan newTermLoan(double commitment, Date start, Date maturity, int riskRating)
        {
            return new Loan(commitment, commitment, start, null, maturity, riskRating);
        }

        public static Loan newRevolver(double commitment, Date start, Date expiry, int riskRating)
        {
            return new Loan(commitment, 0, start, expiry, null, riskRating);
        }

        public static Loan newAdvisedLine(double commitment, Date start, Date expiry, int riskRating)
        {
            if (riskRating > 3) return null;
            Loan advisedLine =
               new Loan(commitment, 0, start, expiry, null, riskRating);
            advisedLine.setUnusedPercentage(0.1);
            return advisedLine;
        }

        public void payment(double amount, Date date)
        {
            payments.Add(new Payment(amount, date));
        }

        public double capital()
        {
            // 有效期为空，到期日不为空，此为定期贷款
            if (expiry == null && maturity != null)
                return commitment * duration() * riskFactor();

            // 有效期不为空，到期日为空，此为循环贷款或建议信用额度贷款
            if (expiry != null && maturity == null)
            {
                if (getUnusedPercentage() != 1.0)  // 信用额度贷款
                    return commitment * getUnusedPercentage() * duration() * riskFactor();
                else                               // 循环贷款
                    return (outstandingRiskAmount() * duration() * riskFactor())
                        + (unusedRiskAmount() * duration() * unusedRiskFactor());
            }

            return 0.0;
        }

        public double duration()
        {
            // 有效期为空，到期日不为空，此为定期贷款
            if (expiry == null && maturity != null)
                return weightedAverageDuration();
            // 有效期不为空，到期日为空，此为循环贷款或建议信用额度贷款
            else if (expiry != null && maturity == null)
                return yearsTo(expiry);
            return 0.0;
        }

        private double weightedAverageDuration()
        {
            double duration = 0.0;
            double weightedAverage = 0.0;
            double sumOfPayments = 0.0;
            foreach (Payment payment in payments)
            {
                sumOfPayments += payment.getAmount();
                weightedAverage += yearsTo(payment.getDate()) * payment.getAmount();
            }
            if (commitment != 0.0)
                duration = weightedAverage / sumOfPayments;
            return duration;
        }

        private double yearsTo(Date endDate)
        {
            Date beginDate = (today == null ? start : today);
            return ((endDate.getTime() - beginDate.getTime()) / MILLIS_PER_DAY) / DAYS_PER_YEAR;
        }

        private double riskFactor()
        {
            return RiskFactor.getFactors().forRating(riskRating);
        }

        private double getUnusedPercentage()
        {
            return unusedPercentage;
        }

        private void setUnusedPercentage(double unusedPercentage)
        {
            this.unusedPercentage = unusedPercentage;
        }

        private double unusedRiskAmount()
        {
            return (commitment - outstanding);
        }

        private double outstandingRiskAmount()
        {
            return outstanding;
        }

        private double unusedRiskFactor()
        {
            return UnusedRiskFactors.getFactors().forRating(riskRating);
        }

    }
}
