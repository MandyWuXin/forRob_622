﻿namespace LoanCalculator
{
    internal class Payment
    {
        private double amount;
        private Date date;

        public Payment(double getAmount, Date getDate)
        {
            this.amount = getAmount;
            this.date = getDate;
        }

        internal double getAmount()
        {
            return amount;
        }

        internal Date getDate()
        {
            return date;
        }
    }
}