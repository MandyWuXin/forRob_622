﻿namespace LoanCalculator
{
    internal static class RiskFactor
    {
        internal static Factors getFactors()
        {
            return new Factors();
        }
    }
}