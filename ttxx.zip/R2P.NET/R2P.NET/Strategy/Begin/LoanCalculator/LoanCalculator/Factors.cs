﻿namespace LoanCalculator
{
    internal class Factors
    {
        internal double forRating(double riskRating)
        {
            return 0.035;
        }
    }
}