﻿using System;

namespace LoanCalculator
{
    public  class Date
    {
        private DateTime dateTime;

        public Date(int year, int month, int day)
        {
            this.dateTime = new DateTime(year, month, day);
        }

        public long getTime()
        {
            return dateTime.Ticks / 10000;
        }
    }
}