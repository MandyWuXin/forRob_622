﻿namespace LoanCalculator
{
    internal static class UnusedRiskFactors
    {
        internal static Factors getFactors()
        {
            return new Factors();
        }
    }
}