﻿using System;
using LoanCalculator;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LoanCalculator_Test
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void testTermLoanSamePayments()
        {
            Date start = new Date(2003, 11, 20);
            Date maturity = new Date(2006, 11, 20);
            Loan termLoan = Loan.newTermLoan(3000, start, maturity, 1);
            termLoan.payment(1000.00, new Date(2004, 11, 20));
            termLoan.payment(1000.00, new Date(2005, 11, 20));
            termLoan.payment(1000.00, new Date(2006, 11, 20));
            Assert.AreEqual(2.0, termLoan.duration(), 0.01);
            Assert.AreEqual(210.00, termLoan.capital(), 0.01);
        }
    }
}
