﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanCalculator
{
    public class CapitalStrategyTermLoan : CapitalStrategy
    {
        public override double capital(Loan loan)
        {
            return loan.Commitment * loan.duration() * riskFactor(loan);

        }

        public override double duration(Loan loan)
        {
            return weightedAverageDuration(loan);
        }

        private double weightedAverageDuration(Loan loan)
        {
            double duration = 0.0;
            double weightedAverage = 0.0;
            double sumOfPayments = 0.0;
            foreach (Payment payment in loan.Payments)
            {
                sumOfPayments += payment.getAmount();
                weightedAverage += yearsTo(payment.getDate(), loan) * payment.getAmount();
            }
            if (loan.Commitment != 0.0)
                duration = weightedAverage / sumOfPayments;
            return duration;
        }
    }
}
