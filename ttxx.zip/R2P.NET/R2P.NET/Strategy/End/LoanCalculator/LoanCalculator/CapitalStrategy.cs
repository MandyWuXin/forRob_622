﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanCalculator
{
    public abstract class CapitalStrategy
    {
        private readonly int MILLIS_PER_DAY = 86400000;
        private readonly int DAYS_PER_YEAR = 365;

        public abstract double capital(Loan loan);

        protected double riskFactor(Loan loan)
        {
            return RiskFactor.getFactors().forRating(loan.RiskRating);
        }

        protected double unusedRiskFactor(Loan loan)
        {
            return UnusedRiskFactors.getFactors().forRating(loan.RiskRating);
        }


        public abstract double duration(Loan loan);

        private double weightedAverageDuration(Loan loan)
        {
            double duration = 0.0;
            double weightedAverage = 0.0;
            double sumOfPayments = 0.0;
            foreach (Payment payment in loan.Payments)
            {
                sumOfPayments += payment.getAmount();
                weightedAverage += yearsTo(payment.getDate(), loan) * payment.getAmount();
            }
            if (loan.Commitment != 0.0)
                duration = weightedAverage / sumOfPayments;
            return duration;
        }

        protected double yearsTo(Date endDate, Loan loan)
        {
            Date beginDate = (loan.Today == null ? loan.Start : loan.Today);
            return ((endDate.getTime() - beginDate.getTime()) / MILLIS_PER_DAY) / DAYS_PER_YEAR;
        }
    }
}
