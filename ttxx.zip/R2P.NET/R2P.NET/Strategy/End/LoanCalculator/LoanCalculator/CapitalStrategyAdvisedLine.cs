﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanCalculator
{
    public class CapitalStrategyAdvisedLine : CapitalStrategy
    {
        public override double capital(Loan loan)
        {
            return loan.Commitment * loan.getUnusedPercentage() * loan.duration() * riskFactor(loan);
        }

        public override double duration(Loan loan)
        {
            return yearsTo(loan.Expiry, loan);
        }
    }
}
