﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanCalculator
{
    // 代码为银行贷款的资金计算类，可以处理定期、循环、建议信用额度三种类型的贷款额度计算
    // 代码中包含了数量可观的用来执行资金计算的条件逻辑，我们将通过 Strategy 模式将其重构
    public class Loan
    {
        //private readonly int MILLIS_PER_DAY = 86400000;
        //private readonly int DAYS_PER_YEAR = 365;

        private Date expiry;
        private Date maturity;
        private Date today;
        private Date start;

        private double commitment;
        private double outstanding;
        private double riskRating;
        private double unusedPercentage;

        private List<Payment> payments = new List<Payment>();
        private CapitalStrategy capitalStrategy;

        private Loan(double commitment, double outstanding, Date start, Date expiry, Date maturity, int riskRating, CapitalStrategy strategy)
        {
            this.commitment = commitment;
            this.outstanding = outstanding;
            this.start = start;
            this.expiry = expiry;
            this.maturity = maturity;
            this.riskRating = riskRating;
            capitalStrategy = strategy;
        }

        public Date Expiry
        {
            get { return expiry; }
            set { expiry = value; }
        }

        public Date Maturity
        {
            get { return maturity; }
            set { maturity = value; }
        }

        public double Commitment
        {
            get { return commitment; }
            set { commitment = value; }
        }

        public double RiskRating
        {
            get { return riskRating; }
            set { riskRating = value; }
        }

        public List<Payment> Payments
        {
            get { return payments; }
            set { payments = value; }
        }

        public Date Today
        {
            get { return today; }
            set { today = value; }
        }

        public Date Start
        {
            get { return start; }
            set { start = value; }
        }

        public static Loan newTermLoan(double commitment, Date start, Date maturity, int riskRating)
        {
            return new Loan(commitment, commitment, start, null, maturity, riskRating, new CapitalStrategyTermLoan());
        }

        public static Loan newRevolver(double commitment, Date start, Date expiry, int riskRating)
        {
            return new Loan(commitment, 0, start, expiry, null, riskRating, new CapitalStrategyRevolver());
        }

        public static Loan newAdvisedLine(double commitment, Date start, Date expiry, int riskRating)
        {
            if (riskRating > 3) return null;
            Loan advisedLine =
               new Loan(commitment, 0, start, expiry, null, riskRating, new CapitalStrategyRevolver());
            advisedLine.setUnusedPercentage(0.1);
            return advisedLine;
        }

        public void payment(double amount, Date date)
        {
            payments.Add(new Payment(amount, date));
        }

        public double capital()
        {
            return capitalStrategy.capital(this);
        }

        public double duration()
        {
            return capitalStrategy.duration(this);
        }

        //private double weightedAverageDuration()
        //{
        //    double duration = 0.0;
        //    double weightedAverage = 0.0;
        //    double sumOfPayments = 0.0;
        //    foreach (Payment payment in payments)
        //    {
        //        sumOfPayments += payment.getAmount();
        //        weightedAverage += yearsTo(payment.getDate()) * payment.getAmount();
        //    }
        //    if (commitment != 0.0)
        //        duration = weightedAverage / sumOfPayments;
        //    return duration;
        //}

        //private double yearsTo(Date endDate)
        //{
        //    Date beginDate = (today == null ? start : today);
        //    return ((endDate.getTime() - beginDate.getTime()) / MILLIS_PER_DAY) / DAYS_PER_YEAR;
        //}

        //private double riskFactor()
        //{
        //    return RiskFactor.getFactors().forRating(riskRating);
        //}

        internal double getUnusedPercentage()
        {
            return unusedPercentage;
        }

        private void setUnusedPercentage(double unusedPercentage)
        {
            this.unusedPercentage = unusedPercentage;
        }

        internal double unusedRiskAmount()
        {
            return (commitment - outstanding);
        }

        internal double outstandingRiskAmount()
        {
            return outstanding;
        }

        //private double unusedRiskFactor()
        //{
        //    return UnusedRiskFactors.getFactors().forRating(riskRating);
        //}
    }
}
