﻿namespace TestResult
{
    public class Frame
    {
    }
}