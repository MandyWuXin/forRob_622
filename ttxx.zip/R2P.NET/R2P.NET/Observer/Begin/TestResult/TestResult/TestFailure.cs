﻿namespace TestResult
{
    internal class TestFailure
    {
        private Throwable t;
        private Test test;

        public TestFailure(Test test, Throwable t)
        {
            this.test = test;
            this.t = t;
        }
    }
}