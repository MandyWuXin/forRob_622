﻿namespace TestResult
{
    public class Throwable
    {
    }
}