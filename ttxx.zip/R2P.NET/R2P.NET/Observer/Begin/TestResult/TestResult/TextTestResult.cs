﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestResult
{
    class TextTestResult : TestResult
    {
        private TextTestRunner fRunner;     // 硬编码需要通知的 TextTestRunner 对象

        public TextTestResult(TextTestRunner textTestRunner)
        {
            this.fRunner = textTestRunner;
        }

        public override void addError(Test test, Throwable t)
        {
            base.addError(test, t);
            fRunner.addError(this, test, t);
        }

        public override void addFailure(Test test, Throwable t)
        {
            base.addFailure(test, t);
            fRunner.addFailure(this, test, t);
        }
    }
}
