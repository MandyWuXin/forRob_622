﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestResult
{
    public class TextTestRunner
    {
        private TestResult fTestResult;
        private TestSuite testSuite;

        //...

        private TestResult createTestResult()
        {
            return new TextTestResult(this);   // 硬编码创建 TextTestResult
        }


        public void runSuite()
        {
            //...
            fTestResult = createTestResult();
            testSuite.run(fTestResult);
        }

        public void addFailure(TestResult result, Test test, Throwable t)
        {
            Console.WriteLine("F");
        }

        public void addError(TestResult result, Test test, Throwable throwable)
        {
            Console.WriteLine("E");
        }
    }
}
