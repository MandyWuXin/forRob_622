﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestResult
{
    public class UITestRunner : Frame     // 基于 GUI 的 UITestRunner
    {
        private TestResult fTestResult;
        private TestSuite testSuite;

        //...

        private TestResult createTestResult()
        {
            return new UITestResult(this);   // 硬编码创建 UITestResult
        }


        public void runSuite()
        {
            //...
            fTestResult = createTestResult();
            testSuite.run(fTestResult);
        }

        public void addFailure(TestResult result, Test test, Throwable t)
        {
            // 在图形界面显示测试失败信息
        }

        public void addError(TestResult result, Test test, Throwable throwable)
        {
            // 在图形界面显示测试失败信息
        }
    }
}
