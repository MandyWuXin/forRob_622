﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestResult
{
    // Step0. 这是 JUnit 框架最初的设计。
    //        TestResult 有 两个子类 UITestResult 和 TextTestResult
    //        TestResult 的子类从测试用例对象中收集信息，以便把这些信息报告给相应的 UITestRunner
    //        UITestResult 被硬编码与一个 UITestRunner 连接起来，以向后者报告信息 （图形信息）
    //        而 TextTestResult 被硬编码与一个 TextTestRunner 连接起来，以向后者报告信息 （文本信息）
    //        当用户要求在运行时使用多个不同的 UITestRunner 对象取得 TestResult 结果时，以上设计就难以满足

    public class TestResult
    {
        private List<TestFailure> fFailures = null;
        private List<TestFailure> fErrors = null;
        private int fRunTests;
        private bool fStop;

        public TestResult()
        {
            fFailures = new List<TestFailure>(10);
            fErrors = new List<TestFailure>(10);
            fRunTests = 0;
            fStop = false;
        }


        public virtual void addFailure(Test test, Throwable t)
        {
            fFailures.Add(new TestFailure(test, t));
        }

        public virtual void addError(Test test, Throwable t)
        {
            fErrors.Add(new TestFailure(test, t));
        }
    }
}
