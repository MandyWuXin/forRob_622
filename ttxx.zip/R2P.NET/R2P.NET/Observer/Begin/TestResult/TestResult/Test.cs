﻿namespace TestResult
{
    public class Test
    {
    }
}