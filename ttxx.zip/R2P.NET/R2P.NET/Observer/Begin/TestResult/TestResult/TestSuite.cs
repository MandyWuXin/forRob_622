﻿using System;

namespace TestResult
{
    internal class TestSuite
    {
        internal void run(TestResult fTestResult)
        {
            throw new NotImplementedException();
        }
    }
}