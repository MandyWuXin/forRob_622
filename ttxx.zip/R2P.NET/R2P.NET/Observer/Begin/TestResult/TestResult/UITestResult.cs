﻿namespace TestResult
{
    public class UITestResult : TestResult
    {
        private UITestRunner fRunner;     // 硬编码需要通知的 UITestRunner 对象

        public UITestResult(UITestRunner uiTestRunner)
        {
            this.fRunner = uiTestRunner;
        }

        public override void addError(Test test, Throwable t)
        {
            base.addError(test, t);
            fRunner.addError(this, test, t);      // 向 UITestRunner 发出通知
        }

        public override void addFailure(Test test, Throwable t)
        {
            base.addFailure(test, t);
            fRunner.addFailure(this, test, t);  // 向 UITestRunner 发出通知
        }
    }
}