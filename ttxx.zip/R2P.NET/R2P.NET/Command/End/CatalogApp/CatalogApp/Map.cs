﻿namespace CatalogApp
{
    public class Map
    {
        public void put(string id, string nextWorkshopId)
        {
            throw new System.NotImplementedException();
        }
    }
}