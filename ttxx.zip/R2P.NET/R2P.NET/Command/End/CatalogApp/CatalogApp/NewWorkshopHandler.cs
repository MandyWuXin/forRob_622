﻿namespace CatalogApp
{
    internal class NewWorkshopHandler : Handler
    {
        private CatalogApp _catalogApp;

        public NewWorkshopHandler(CatalogApp catalogApp)
            : base(catalogApp)
        {
            _catalogApp = catalogApp;
        }

        internal HandlerResponse getNewWorkshopResponse(Map parameters)
        {
            string nextWorkshopID = WorkshopManager.getNextWorkshopID();
            StringBuffer newWorkshopContents =
                WorkshopManager.createNewFileFromTemplate(
                    nextWorkshopID,
                    WorkshopManager.getWorkshopDir(),
                    WorkshopManager.getWorkshopTemplate()
                );
            WorkshopManager.addWorkshop(newWorkshopContents);
            parameters.put("id", nextWorkshopID);
            return _catalogApp.executeActionAndGetResponse(CatalogApp.ALL_WORKSHOPS, parameters);
        }

        public override HandlerResponse execute(Map parameters)
        {
            return getNewWorkshopResponse(parameters);
        }
    }
}