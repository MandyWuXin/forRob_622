﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatalogApp
{
    // Step0. CatalogApp 类负责根据不同的情况进行调度，执行动作，并返回响应
    //        CatalogApp 使用一个庞大的条件语句来执行这些任务
    //        当需要按照众多不同的条件去做某些操作的时候，就可以重构到 Command 模式

    public class CatalogApp
    {
        private static readonly string NEW_WORKSHOP = "NEW_WORKSHOP";
        internal static readonly string ALL_WORKSHOPS = "ALL_WORKSHOPS";
        internal static readonly string ALL_WORKSHOPS_STYLESHEET = "ALL_WORKSHOPS_STYLESHEET";
        private readonly NewWorkshopHandler _newWorkshopHandler;
        private readonly AllWorkshopsHandler _allWorkshopsHandler;

        private Dictionary<string, Handler> handlers;

        public CatalogApp()
        {
            _newWorkshopHandler = new NewWorkshopHandler(this);
            _allWorkshopsHandler = new AllWorkshopsHandler(this);

            createHandlers();
        }

        internal HandlerResponse executeActionAndGetResponse(string actionName, Map parameters)
        {
            //if (actionName.Equals(NEW_WORKSHOP))    // 当处理一个新的研讨班时
            //{
            //    return _newWorkshopHandler.execute(parameters);
            //}
            //else if (actionName.Equals(ALL_WORKSHOPS))  // 当处理所有研讨班时
            //{
            //    return _allWorkshopsHandler.execute(parameters);
            //}
            //// ... 还有很多的 else if

            //return null;

            Handler handler = lookupHandlerBy(actionName);
            return handler.execute(parameters);
        }

        private void createHandlers()
        {
            handlers = new Dictionary<string, Handler>();
            handlers.Add(NEW_WORKSHOP, new NewWorkshopHandler(this));
            handlers.Add(ALL_WORKSHOPS, new AllWorkshopsHandler(this));
        }

        private Handler lookupHandlerBy(String actionName)
        {
            Handler result = new AllWorkshopsHandler(this);
            handlers.TryGetValue(actionName, out result);
            return result;
        }
    }
}
