﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatalogApp
{
    public abstract class Handler
    {
        protected CatalogApp catalogApp;

        public Handler(CatalogApp catalogApp)
        {
            this.catalogApp = catalogApp;
        }

        public abstract HandlerResponse execute(Map parameters);
    }

}
