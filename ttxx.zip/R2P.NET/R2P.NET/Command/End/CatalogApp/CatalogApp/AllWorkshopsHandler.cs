﻿using System;

namespace CatalogApp
{
    internal class AllWorkshopsHandler : Handler
    {
        private CatalogApp _catalogApp;

        public AllWorkshopsHandler(CatalogApp catalogApp)
            : base(catalogApp)
        {
            _catalogApp = catalogApp;
        }

        internal HandlerResponse getAllWorkshopsResponse()
        {
            XMLBuilder allWorkshopsXml = new XMLBuilder("workshops");
            WorkshopRepository repository =
                WorkshopManager.getWorkshopRepository();
            Iterator ids = repository.keyIterator();
            while (ids.hasNext())
            {
                string id = (string) ids.next();
                Workshop workshop = repository.getWorkshop(id);
                allWorkshopsXml.addBelowParent("workshop");
                allWorkshopsXml.addAttribute("id", workshop.getID());
                allWorkshopsXml.addAttribute("name", workshop.getName());
                allWorkshopsXml.addAttribute("status", workshop.getStatus());
                allWorkshopsXml.addAttribute("duration",
                    workshop.getDurationAsString());
            }

            string formattedXml = getFormattedData(allWorkshopsXml.toString());
            return new HandlerResponse(new StringBuffer(formattedXml), CatalogApp.ALL_WORKSHOPS_STYLESHEET);
        }

        private string getFormattedData(string allWorkshops)
        {
            throw new NotImplementedException();
        }

        public override HandlerResponse execute(Map parameters)
        {
            return getAllWorkshopsResponse();
        }
    }
}