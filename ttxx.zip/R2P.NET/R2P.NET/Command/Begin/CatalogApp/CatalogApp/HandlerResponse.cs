﻿namespace CatalogApp
{
    internal class HandlerResponse
    {
        private string aLL_WORKSHOPS_STYLESHEET;
        private StringBuffer stringBuffer;

        public HandlerResponse(StringBuffer stringBuffer, string aLL_WORKSHOPS_STYLESHEET)
        {
            this.stringBuffer = stringBuffer;
            this.aLL_WORKSHOPS_STYLESHEET = aLL_WORKSHOPS_STYLESHEET;
        }
    }
}