﻿namespace CatalogApp
{
    internal class XMLBuilder
    {
        private string v;

        public XMLBuilder(string v)
        {
            this.v = v;
        }

        public string toString()
        {
            throw new System.NotImplementedException();
        }

        public void addBelowParent(string workshop)
        {
            throw new System.NotImplementedException();
        }

        public void addAttribute(string id, object getId)
        {
            throw new System.NotImplementedException();
        }
    }
}