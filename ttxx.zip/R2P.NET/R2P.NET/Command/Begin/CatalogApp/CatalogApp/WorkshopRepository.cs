﻿namespace CatalogApp
{
    internal class WorkshopRepository
    {
        public Workshop getWorkshop(string id)
        {
            throw new System.NotImplementedException();
        }

        public Iterator keyIterator()
        {
            throw new System.NotImplementedException();
        }
    }
}