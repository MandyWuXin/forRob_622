﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatalogApp
{
    // Step0. CatalogApp 类负责根据不同的情况进行调度，执行动作，并返回响应
    //        CatalogApp 使用一个庞大的条件语句来执行这些任务
    //        当需要按照众多不同的条件去做某些操作的时候，就可以重构到 Command 模式

    internal class CatalogApp
    {
        private static readonly string NEW_WORKSHOP = "NEW_WORKSHOP";
        private static readonly string ALL_WORKSHOPS = "ALL_WORKSHOPS";
        private static readonly string ALL_WORKSHOPS_STYLESHEET = "ALL_WORKSHOPS_STYLESHEET";

        private HandlerResponse executeActionAndGetResponse(string actionName, Map parameters)
        {
            if (actionName.Equals(NEW_WORKSHOP))    // 当处理一个新的研讨班时
            {
                string nextWorkshopID = WorkshopManager.getNextWorkshopID();
                StringBuffer newWorkshopContents =
                    WorkshopManager.createNewFileFromTemplate(
                        nextWorkshopID,
                        WorkshopManager.getWorkshopDir(),
                        WorkshopManager.getWorkshopTemplate()
                        );
                WorkshopManager.addWorkshop(newWorkshopContents);
                parameters.put("id", nextWorkshopID);
                return executeActionAndGetResponse(ALL_WORKSHOPS, parameters);
            }
            else if (actionName.Equals(ALL_WORKSHOPS))  // 当处理所有研讨班时
            {
                XMLBuilder allWorkshopsXml = new XMLBuilder("workshops");
                WorkshopRepository repository =
                    WorkshopManager.getWorkshopRepository();
                Iterator ids = repository.keyIterator();
                while (ids.hasNext())
                {
                    string id = (string) ids.next();
                    Workshop workshop = repository.getWorkshop(id);
                    allWorkshopsXml.addBelowParent("workshop");
                    allWorkshopsXml.addAttribute("id", workshop.getID());
                    allWorkshopsXml.addAttribute("name", workshop.getName());
                    allWorkshopsXml.addAttribute("status", workshop.getStatus());
                    allWorkshopsXml.addAttribute("duration",
                        workshop.getDurationAsString());
                }
                string formattedXml = getFormattedData(allWorkshopsXml.toString());
                return new HandlerResponse(new StringBuffer(formattedXml), ALL_WORKSHOPS_STYLESHEET);
            }
            // ... 还有很多的 else if

            return null;
        }

        private string getFormattedData(string allWorkshops)
        {
            throw new NotImplementedException();
        }
    }
}
