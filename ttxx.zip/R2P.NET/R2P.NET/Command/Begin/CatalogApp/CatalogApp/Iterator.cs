﻿namespace CatalogApp
{
    internal class Iterator
    {
        public bool hasNext()
        {
            throw new System.NotImplementedException();
        }

        public string next()
        {
            throw new System.NotImplementedException();
        }
    }
}