﻿namespace CatalogApp
{
    internal class WorkshopManager
    {
        public static string getNextWorkshopID()
        {
            throw new System.NotImplementedException();
        }

        public static void addWorkshop(StringBuffer newWorkshopContents)
        {
            throw new System.NotImplementedException();
        }

        public static string getWorkshopDir()
        {
            throw new System.NotImplementedException();
        }

        public static string getWorkshopTemplate()
        {
            throw new System.NotImplementedException();
        }

        public static StringBuffer createNewFileFromTemplate(string nextWorkshopId, string s, string getWorkshopTemplate1)
        {
            throw new System.NotImplementedException();
        }

        public static WorkshopRepository getWorkshopRepository()
        {
            throw new System.NotImplementedException();
        }
    }
}