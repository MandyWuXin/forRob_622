﻿namespace CatalogApp
{
    internal class Workshop
    {
        public object getID()
        {
            throw new System.NotImplementedException();
        }

        public object getName()
        {
            throw new System.NotImplementedException();
        }

        public object getStatus()
        {
            throw new System.NotImplementedException();
        }

        public object getDurationAsString()
        {
            throw new System.NotImplementedException();
        }
    }
}