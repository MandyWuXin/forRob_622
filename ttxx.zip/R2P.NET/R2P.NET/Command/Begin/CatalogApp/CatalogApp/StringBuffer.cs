﻿using System.Text;

namespace CatalogApp
{
    public class StringBuffer
    {
        private StringBuilder builder = new StringBuilder();

        public StringBuffer(string formattedXml)
        {
            builder.Append(formattedXml);
        }

        public void append(string str)
        {
            builder.Append(str);
        }

        public string toString()
        {
            return builder.ToString();
        }
    }
}