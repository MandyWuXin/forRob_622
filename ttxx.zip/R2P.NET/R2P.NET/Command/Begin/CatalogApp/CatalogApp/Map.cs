﻿namespace CatalogApp
{
    internal class Map
    {
        public void put(string id, string nextWorkshopId)
        {
            throw new System.NotImplementedException();
        }
    }
}