﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermissionControl
{
    public class PermissionRequested : PermissionState
    {
        public PermissionRequested()
            : base("REQUESTED")
        {
        }

        public override void claimedBy(SystemAdmin admin, SystemPermission permission)
        {
            permission.willBeHandledBy(admin);
            permission.State = PermissionState.CLAIMED;
        }
    }
}
