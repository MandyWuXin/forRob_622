﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermissionControl
{
    public class UnixPermissionClaimed : PermissionState
    {
        public UnixPermissionClaimed()
            : base("UNIX_CLAIMED")
        {
        }

        public override void deniedBy(SystemAdmin admin, SystemPermission permission)
        {
            if (!permission.Admin.Equals(admin))
                return;

            permission.Granted = false;
            permission.UnixPermissionGranted = false;
            permission.State = PermissionState.DENIED;
            permission.notifyUserOfPermissionRequestResult();
        }

        public override void grantedBy(SystemAdmin admin, SystemPermission permission)
        {
            if (!permission.Admin.Equals(admin))
                return;

            if (permission.Profile.isUnixPermissionRequired())
                permission.UnixPermissionGranted = true;
            else if (permission.Profile.isUnixPermissionRequired() && !permission.isUnixPermissionGranted())
            {
                permission.State = PermissionState.UNIX_REQUESTED;
                permission.notifyUnixAdminsOfPermissionRequest();
                return;
            }

            permission.State = PermissionState.GRANTED;
            permission.Granted = true;
            permission.notifyUserOfPermissionRequestResult();
        }
    }
}
