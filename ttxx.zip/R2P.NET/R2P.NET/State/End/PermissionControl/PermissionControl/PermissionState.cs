﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermissionControl
{
    public abstract class PermissionState
    {
        private string name;

        protected PermissionState(string name)
        {
            this.name = name;
        }

        public static readonly PermissionState REQUESTED = new PermissionRequested();
        public static readonly PermissionState CLAIMED = new PermissionClaimed();
        public static readonly PermissionState GRANTED = new PermissionGranted();
        public static readonly PermissionState DENIED = new PermissionDenied();
        public static readonly PermissionState UNIX_REQUESTED = new UnixPermissionRequested();
        public static readonly PermissionState UNIX_CLAIMED = new UnixPermissionClaimed();

        public string Name
        {
            get { return name; }
        }

        public virtual void claimedBy(SystemAdmin admin, SystemPermission permission)
        {
            
        }

        public virtual void deniedBy(SystemAdmin admin, SystemPermission permission)
        {
            
        }

        public virtual void grantedBy(SystemAdmin admin, SystemPermission permission)
        {
            
        }
    }
}
