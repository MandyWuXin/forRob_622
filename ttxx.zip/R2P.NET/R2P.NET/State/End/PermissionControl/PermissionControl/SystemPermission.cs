﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermissionControl
{
    // 在 SystemPermission 类加入了越来越多的真实世界的行为后，其状态改变逻辑将变得晦涩复杂
    // 比如，用户在被授予访问指定软件系统的通用权限之前，必须获得 UNIX 权限
    
    // 虽然可以试着通过 Extract Method 简化 grantedBy() 等函数，但是这些函数的判断逻辑还是过于复杂
    // 这可以通过 state 模式简化

    public class SystemPermission
    {
        private SystemProfile profile;
        private SystemUser requestor;
        private SystemAdmin admin = new SystemAdmin();
        private bool granted;
        private PermissionState state;

        // 新的 UNIX 权限相关的变量
        private bool unixPermissionGranted;

        public SystemPermission(SystemUser requestor, SystemProfile profile)
        {
            this.requestor = requestor;
            this.profile = profile;
            state = PermissionState.REQUESTED;
            granted = false;
            notifyAdminOfPermissionRequest();
        }

        public PermissionState State
        {
            get { return state; }
            set { state = value; }
        }

        public SystemAdmin Admin
        {
            get { return admin; }
            set { admin = value; }
        }

        public bool Granted
        {
            get { return granted; }
            set { granted = value; }
        }

        public bool UnixPermissionGranted
        {
            get { return unixPermissionGranted; }
            set { unixPermissionGranted = value; }
        }

        public SystemProfile Profile
        {
            get { return profile; }
            set { profile = value; }
        }

        private void notifyAdminOfPermissionRequest()
        {
            // notify code goes here.
        }

        public void claimedBy(SystemAdmin admin)
        {
            state.claimedBy(admin, this);

        }

        internal void willBeHandledBy(SystemAdmin systemAdmin)
        {
            // handle code goes here.
        }

        public void deniedBy(SystemAdmin admin)
        {
            state.deniedBy(admin, this);
        }

        internal void notifyUserOfPermissionRequestResult()
        {
            // notify code goes here.
        }

        public void grantedBy(SystemAdmin admin)
        {
            state.grantedBy(admin, this);
        }

        internal void notifyUnixAdminsOfPermissionRequest()
        {
            // notify code goes here.
        }

        public bool isGranted()
        {
            return granted;
        }

        // 添加新的 UNIX 权限相关的变量的 get 函数
        internal bool isUnixPermissionGranted()
        {
            return unixPermissionGranted;
        }
    }
}
