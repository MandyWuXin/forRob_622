﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermissionControl
{
    public class UnixPermissionRequested : PermissionState
    {
        public UnixPermissionRequested()
            : base("UNIX_REQUESTED")
        {
        }

        public override void claimedBy(SystemAdmin admin, SystemPermission permission)
        {
            permission.willBeHandledBy(admin);
            permission.State = PermissionState.UNIX_CLAIMED;
        }
    }
}
