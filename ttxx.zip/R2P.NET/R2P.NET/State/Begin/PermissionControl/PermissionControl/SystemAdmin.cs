﻿namespace PermissionControl
{
    public class SystemAdmin
    {
        public override bool Equals(object obj)
        {
            return true;
        }
    }
}