﻿namespace PermissionControl
{
    public class SystemUser
    {
    }
}