﻿namespace PermissionControl
{
    public class SystemProfile
    {
        private bool unixPermissionRequired = false;
        public bool isUnixPermissionRequired()
        {
            return unixPermissionRequired;
        }

        public void setUnixPermissionRequired(bool unixPermissionRequired)
        {
            this.unixPermissionRequired = unixPermissionRequired;
        }
    }
}