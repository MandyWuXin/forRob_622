﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermissionControl
{
    // 在 SystemPermission 类加入了越来越多的真实世界的行为后，其状态改变逻辑将变得晦涩复杂
    // 比如，用户在被授予访问指定软件系统的通用权限之前，必须获得 UNIX 权限
    
    // 虽然可以试着通过 Extract Method 简化 grantedBy() 等函数，但是这些函数的判断逻辑还是过于复杂
    // 这可以通过 state 模式简化

    public class SystemPermission
    {
        private SystemProfile profile;
        private SystemUser requestor;
        private SystemAdmin admin = new SystemAdmin();
        private bool granted;
        private string state;

        // 新的 UNIX 权限相关的变量
        private bool unixPermissionGranted;

        public readonly static string REQUESTED = "REQUESTED";
        public readonly static string CLAIMED = "CLAIMED";
        public readonly static string GRANTED = "GRANTED";
        public readonly static string DENIED = "DENIED";
        
        // 添加新的 UNIX 权限相关的状态值
        public readonly static string UNIX_REQUESTED = "UNIX_REQUESTED";
        public readonly static string UNIX_CLAIMED = "UNIX_CLAIMED";

        public SystemPermission(SystemUser requestor, SystemProfile profile)
        {
            this.requestor = requestor;
            this.profile = profile;
            state = REQUESTED;
            granted = false;
            notifyAdminOfPermissionRequest();
        }

        private void notifyAdminOfPermissionRequest()
        {
            // notify code goes here.
        }

        public void claimedBy(SystemAdmin admin)
        {
            #region Step0 process logic
            //if (!state.Equals(REQUESTED))
            //    return;
            //willBeHandledBy(admin);
            //state = CLAIMED; 
            #endregion

            // 添加 UNIX 权限相关逻辑
            if (!state.Equals(REQUESTED) && !state.Equals(UNIX_REQUESTED))
                return;
            willBeHandledBy(admin);
            if (state.Equals(REQUESTED))
                state = CLAIMED;
            else if (state.Equals(UNIX_REQUESTED))
                state = UNIX_CLAIMED;

        }

        private void willBeHandledBy(SystemAdmin systemAdmin)
        {
            // handle code goes here.
        }

        public void deniedBy(SystemAdmin admin)
        {
            #region Step0 process logic
            //if (!state.Equals(CLAIMED))
            //    return;
            //if (!this.admin.Equals(admin))
            //    return;
            //granted = false;
            //state = DENIED;
            //notifyUserOfPermissionRequestResult(); 
            #endregion

            // 添加 UNIX 权限相关逻辑
            if (!state.Equals(CLAIMED) && !state.Equals(UNIX_CLAIMED))
                return;
            if (!this.admin.Equals(admin))
                return;
            granted = false;
            unixPermissionGranted = false;
            state = DENIED;
            notifyUserOfPermissionRequestResult();
        }

        private void notifyUserOfPermissionRequestResult()
        {
            // notify code goes here.
        }

        public void grantedBy(SystemAdmin admin)
        {
            #region Step0 process logic
            //if (!state.Equals(CLAIMED))
            //    return;
            //if (!this.admin.Equals(admin))
            //    return;
            //state = GRANTED;
            //granted = true;
            //notifyUserOfPermissionRequestResult(); 
            #endregion

            // 添加 UNIX 权限相关逻辑
            if (!state.Equals(CLAIMED) && !state.Equals(UNIX_CLAIMED))
                return;
            if (!this.admin.Equals(admin))
                return;

            if (profile.isUnixPermissionRequired() && state.Equals(UNIX_CLAIMED))
                unixPermissionGranted = true;
            else if (profile.isUnixPermissionRequired() && !isUnixPermissionGranted())
            {
                state = UNIX_REQUESTED;
                notifyUnixAdminsOfPermissionRequest();
                return;
            }
            state = GRANTED;
            granted = true;
            notifyUserOfPermissionRequestResult();

        }

        private void notifyUnixAdminsOfPermissionRequest()
        {
            // notify code goes here.
        }

        public string getState()
        {
            return state;
        }

        public bool isGranted()
        {
            return granted;
        }

        // 添加新的 UNIX 权限相关的变量的 get 函数
        private bool isUnixPermissionGranted()
        {
            return unixPermissionGranted;
        }
    }
}
