﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PermissionControl;

namespace PermissionControl_Test
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void testGrantedBy()
        {
            SystemUser user = new SystemUser();
            SystemProfile profile = new SystemProfile();
            SystemPermission permission = new SystemPermission(user, profile);

            SystemAdmin admin = new SystemAdmin();
            permission.grantedBy(admin);
            Assert.AreEqual(SystemPermission.REQUESTED, permission.getState());
            Assert.AreEqual(false, permission.isGranted());

            permission.claimedBy(admin);
            permission.grantedBy(admin);
            Assert.AreEqual(SystemPermission.GRANTED, permission.getState());
            Assert.AreEqual(true, permission.isGranted());
        }

        [TestMethod]
        public void testGrantedByWithUnixConcerned()
        {
            SystemUser user = new SystemUser();
            SystemProfile profile = new SystemProfile();
            profile.setUnixPermissionRequired(true);
            SystemPermission permission = new SystemPermission(user, profile);

            SystemAdmin admin = new SystemAdmin();
            permission.grantedBy(admin);
            Assert.AreEqual(SystemPermission.REQUESTED, permission.getState());
            Assert.AreEqual(false, permission.isGranted());

            permission.claimedBy(admin);
            permission.grantedBy(admin);
            Assert.AreEqual(SystemPermission.UNIX_REQUESTED, permission.getState());
            Assert.AreEqual(false, permission.isGranted());

            permission.claimedBy(admin);
            Assert.AreEqual(SystemPermission.UNIX_CLAIMED, permission.getState());
            Assert.AreEqual(false, permission.isGranted());

            permission.grantedBy(admin);
            Assert.AreEqual(SystemPermission.GRANTED, permission.getState());
            Assert.AreEqual(true, permission.isGranted());
        }
    }
}
